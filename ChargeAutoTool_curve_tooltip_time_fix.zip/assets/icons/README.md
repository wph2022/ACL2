# Icon resources

请把你提供的 ACL 图标资源放到以下路径：

- `assets/icons/acl.png`：应用窗口左上角图标（运行时加载）
- `assets/icons/acl.ico`：Windows EXE 图标（PyInstaller `--icon`）

建议由同一原图导出，保持视觉一致。
