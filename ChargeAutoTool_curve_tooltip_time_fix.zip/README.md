# ChargeAutoTool

已按你给出的目录结构将原单文件脚本重写为模块化项目：

- `run.py`：应用入口
- `config.py`：全局配置
- `core/`：ADB、时间同步、解析基类、基础线程
- `utils/`：命令与日志工具
- `ui/`：主窗口、样式、可复用控件
- `modules/`：日志分析、寄存器分析、AI 分析（预留）
- `LOGS/`：运行日志目录（实时记录关键操作，含异常堆栈，支持日志滚动，便于问题定位与审计）

## 运行（推荐）

> 推荐始终在仓库根目录执行，避免路径歧义。

```bash
python -m ChargeAutoTool
# 或
python -m ChargeAutoTool.run
```

## 运行（按当前目录）

- 当前目录在仓库根目录（包含 `ChargeAutoTool/`）时：

```bash
python ChargeAutoTool/run.py
```

- 当前目录已进入 `ChargeAutoTool/` 时：

```bash
python run.py
```

## 打包 EXE（Windows / PyInstaller）

1. 安装依赖：

```bash
pip install pyinstaller
```

2. 准备图标资源（你提供的 ACL 图标）：

- `assets/icons/acl.png`（应用窗口左上角图标）
- `assets/icons/acl.ico`（EXE 图标）

3. 在仓库根目录执行打包：

```bash
python -m PyInstaller -y --clean --windowed --name ChargeAutoTool ^
  --icon assets/icons/acl.ico ^
  --collect-binaries python ^
  --collect-binaries PySide6 ^
  --add-data "assets;assets" ^
  ChargeAutoTool/run.py
```

或直接运行：

```bash
scripts\build_exe.bat
```



> 若打包后运行时看到 CMD 窗口频繁闪烁，通常是后台 adb 子进程每次调用都会弹控制台。当前代码已在 Windows 下对 `subprocess` 增加 `CREATE_NO_WINDOW`，可抑制该问题。

4. 打包结果：

- `dist/ChargeAutoTool/ChargeAutoTool.exe`（可执行文件）

## 工程方案与优化建议

详见：`docs/ENGINEERING_GUIDE.md`

## 依赖

- Python 3.9+
- PySide6
- adb
