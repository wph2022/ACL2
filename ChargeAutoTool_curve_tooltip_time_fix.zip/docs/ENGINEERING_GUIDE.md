# ChargeAutoTool 工程运行、打包、操作与扩展方案

## 1. 现状检查（风险与改进点）

### 1.1 运行入口风险
- 之前只给了 `python3 ChargeAutoTool/run.py`，在 Windows 且目录不同时容易出现路径误用（例如在 `ChargeAutoTool/` 目录内又执行 `python ChargeAutoTool/run.py`）。
- 已优化：
  - 新增 `python -m ChargeAutoTool` 入口（`__main__.py`）。
  - `run.py` 支持在包目录内直接 `python run.py` 执行。

### 1.2 依赖与环境风险
- 运行依赖 `PySide6` 和 `adb`，若环境未安装或 PATH 未配置，会导致启动或设备功能失败。
- 建议增加 `requirements.txt` 与启动前环境自检（后续可做）。

### 1.3 稳定性与可维护性风险
- 当前已接入全局异常捕获与滚动日志，方向正确。
- 后续建议补充：
  - 各模块最小自动化测试（特别是解析器与导出逻辑）。
  - 打包后 smoke test 脚本（验证 exe 可启动、LOGS 目录可写）。

## 2. 推荐运行方式

### 2.1 最推荐（跨平台统一）
```bash
python -m ChargeAutoTool
```

### 2.2 兼容方式
- 在仓库根目录：
```bash
python ChargeAutoTool/run.py
```
- 在 `ChargeAutoTool/` 目录：
```bash
python run.py
```

## 3. Windows 打包 EXE 方案（PyInstaller）

### 3.1 一次性命令
在仓库根目录执行（含图标和静态资源）：
```bash
python -m PyInstaller -y --clean --windowed --name ChargeAutoTool \
  --icon assets/icons/acl.ico \
  --collect-binaries python \
  --collect-binaries PySide6 \
  --add-data "assets;assets" \
  ChargeAutoTool/run.py
```

### 3.2 图标资源
- `assets/icons/acl.png`：运行时窗口左上角图标
- `assets/icons/acl.ico`：打包后的 EXE 图标

### 3.3 脚本化打包
仓库提供 `scripts/build_exe.bat`：
```bat
scripts\build_exe.bat
```
输出路径：`dist\ChargeAutoTool\ChargeAutoTool.exe`

### 3.4 打包注意事项
- 若出现 Qt 插件缺失，建议补充 `--collect-all PySide6`。
- 若 exe 运行时出现 CMD 持续闪烁，通常源于后台 `subprocess` 调用弹窗；本工程已在 Windows 子进程参数中使用 `CREATE_NO_WINDOW` 进行抑制。
- 如需单文件可尝试 `--onefile`，但启动速度和杀软误报风险通常更高。
- 建议保留目录模式（当前方案）作为量产默认。

## 4. 功能操作建议（用于现场与审计）

### 4.1 日志分析
- 先选择目录，再执行分析与导出。
- 导出前先检查结果预览，避免重复导出无效数据。
- 问题定位时优先收集 `ChargeAutoTool/LOGS/` 下当日日志。

### 4.2 寄存器分析
- 执行写寄存器/i2cdump 前确认设备唯一连接。
- 异常情况下保留命令输出和 `LOGS` 日志，便于复盘。

### 4.3 审计留痕
- 目前已覆盖关键操作和异常堆栈落盘，建议发布版保持开启。
- 建议运维规范：问题单附带 `LOGS` + 导出 CSV + 操作时间段。

## 5. 后续扩展方案（分阶段）

### Phase A：可运维化（短期）
- 增加 `requirements.txt`、`constraints.txt`。
- 增加“环境自检”按钮（PySide6/adb/path/权限）。
- 增加“打开日志目录”快捷入口。

### Phase B：可测试化（中期）
- 为 `modules/log_analysis/parsers.py` 增加样例驱动测试。
- 为导出逻辑增加回归测试（CSV 字段顺序、空值处理）。
- 新增 CI：`python -m compileall ChargeAutoTool` + 单元测试。

### Phase C：可扩展化（中长期）
- 为 `modules/ai_analysis` 设计插件协议（provider 接口 + 配置文件）。
- 模块能力注册中心（菜单自动发现）。
- 统一任务总线（后台任务可中断、可重试、可追踪）。

## 6. 发布建议（给你落地用）
- 开发调试：`python -m ChargeAutoTool`
- 对外试用：PyInstaller 目录版（本仓库脚本）
- 正式发布：
  1. 锁版本依赖
  2. 记录 git commit
  3. 打包 smoke test
  4. 附带 `LOGS` 收集说明

