# -*- coding: utf-8 -*-
"""Stable data contracts for analysis results.

This is a minimal first step. Current parsers/workers may still output legacy
dicts; UI can gradually migrate to these dataclasses without breaking changes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple


@dataclass
class CurveSeries:
    name: str
    x: Sequence[float]
    y: Sequence[float]
    unit_x: str = ""
    unit_y: str = ""
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AnalysisArtifact:
    kind: str
    path: str
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AnalysisResult:
    """Unified result container for one analysis run."""

    name: str
    meta: Dict[str, Any] = field(default_factory=dict)
    tables: Dict[str, Any] = field(default_factory=dict)   # table_name -> dataframe/rows
    curves: List[CurveSeries] = field(default_factory=list)
    artifacts: List[AnalysisArtifact] = field(default_factory=list)
