"""Domain models (stable schemas).

These models provide a consistent contract between parsers, storage, charts and
exporters. Keep them stable; extend via new fields/classes.
"""
