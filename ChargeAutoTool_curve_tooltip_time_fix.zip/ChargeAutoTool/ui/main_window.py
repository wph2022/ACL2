import sys
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QFrame, QVBoxLayout, QGroupBox, QGridLayout, QPushButton, QStackedWidget
from ChargeAutoTool.config import UI
from ChargeAutoTool.ui.widgets.device_monitor import DeviceMonitor
from ChargeAutoTool.modules.log_analysis.controls import LogControls
from ChargeAutoTool.modules.log_analysis.results import LogResults
from ChargeAutoTool.modules.register_analysis.controls import RegControls
from ChargeAutoTool.modules.register_analysis.results import RegResults
from ChargeAutoTool.utils.logger import UILogger
from ChargeAutoTool.core.settings import AppSettings
from ChargeAutoTool.app.bus import EventBus
from ChargeAutoTool.core.task_runner import TaskRunner

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("ACL"); self.resize(1350,860); self._serial=""; self.op_logger=UILogger(Path(__file__).resolve().parents[1] / "LOGS")

        # Cross-cutting primitives (minimal integration):
        # - EventBus: decouple module outputs from UI reactions (future-proof)
        # - TaskRunner: unify QThread lifecycle tracking (start/finish/fail/cancel)
        self.bus = EventBus(self)
        self.task_runner = TaskRunner(bus=self.bus, parent=self)
        self.settings = AppSettings()
        central=QWidget(); self.setCentralWidget(central); root=QHBoxLayout(central); root.setContentsMargins(UI.PAD,UI.PAD,UI.PAD,UI.PAD); root.setSpacing(UI.GAP)
        left=QFrame(); lv=QVBoxLayout(left); lv.setContentsMargins(0,0,0,0); lv.setSpacing(UI.GAP)
        nav_box=QGroupBox("功能"); nav_grid=QGridLayout(nav_box); self.nav_items=[("log","🧾 日志分析"),("reg","🧩 寄存器分析")]; self.nav_buttons=[]
        nav_grid.setHorizontalSpacing(8); nav_grid.setVerticalSpacing(8)
        nav_font=QFont(); nav_font.setPointSize(UI.NAV_FONT_PT); nav_font.setBold(True)
        for idx,(_,title) in enumerate(self.nav_items):
            b=QPushButton(title); b.setCursor(Qt.PointingHandCursor); b.setFont(nav_font); b.setProperty("nav", "true"); self.nav_buttons.append(b); nav_grid.addWidget(b, idx//2, idx%2)
        lv.addWidget(nav_box,0); self.ctrl_stack=QStackedWidget(); lv.addWidget(self.ctrl_stack,1)
        div=QFrame(); div.setFrameShape(QFrame.VLine); div.setFixedWidth(1); self.right_stack=QStackedWidget()
        self.log_ctrl=LogControls(self); self.log_res=LogResults(); self.log_ctrl.attach_results(self.log_res)
        self.reg_ctrl=RegControls(self); self.reg_res=RegResults(); self.reg_ctrl.attach_results(self.reg_res)
        self.ctrl_stack.addWidget(self.log_ctrl); self.ctrl_stack.addWidget(self.reg_ctrl)
        self.right_stack.addWidget(self.log_res); self.right_stack.addWidget(self.reg_res)
        root.addWidget(left, UI.LEFT_RATIO); root.addWidget(div,0); root.addWidget(self.right_stack, UI.RIGHT_RATIO)
        self.nav_buttons[0].clicked.connect(lambda: self.set_page(0)); self.nav_buttons[1].clicked.connect(lambda: self.set_page(1)); self.set_page(0)
        self.monitor=DeviceMonitor(poll_ms=1200); self.monitor.changed.connect(self._on_devices); self.monitor.start()

        # Route task lifecycle into operation log (helps field debugging).
        self.task_runner.task_started.connect(lambda tid, name: self.log_operation(f"任务开始: {name} ({tid})"))
        self.task_runner.task_finished.connect(lambda tid, name: self.log_operation(f"任务完成: {name} ({tid})"))
        self.task_runner.task_failed.connect(lambda tid, name, err: self.log_operation(f"任务失败: {name} ({tid}) err={err.splitlines()[0] if err else 'unknown'}"))
        self.task_runner.task_canceled.connect(lambda tid, name: self.log_operation(f"任务取消: {name} ({tid})"))

        # restore window state
        try:
            geo = self.settings.get_bytes(self.settings.keys.window_geometry)
            if geo:
                self.restoreGeometry(geo)
            st = self.settings.get_bytes(self.settings.keys.window_state)
            if st:
                self.restoreState(st)
        except Exception:
            pass

    def closeEvent(self, event):
        try:
            self.settings.set_bytes(self.settings.keys.window_geometry, self.saveGeometry())
            self.settings.set_bytes(self.settings.keys.window_state, self.saveState())
        except Exception:
            pass
        return super().closeEvent(event)
    def log_operation(self, msg:str):
        try: self.op_logger.write(msg)
        except Exception: pass
    def device_serial(self)->str: return self._serial
    def _on_devices(self, serial:str, status_text:str, devs:list):
        if serial != self._serial: self.log_operation(f"设备状态变化: serial={serial or 'NONE'}, status={status_text}")
        self._serial=serial; self.log_ctrl.set_device_status(status_text); self.reg_ctrl.set_device_status(status_text)
    def set_page(self, idx:int):
        self.ctrl_stack.setCurrentIndex(idx); self.right_stack.setCurrentIndex(idx)
        for i,b in enumerate(self.nav_buttons):
            b.setProperty("active", "true" if i == idx else "false")
            b.style().unpolish(b); b.style().polish(b)
