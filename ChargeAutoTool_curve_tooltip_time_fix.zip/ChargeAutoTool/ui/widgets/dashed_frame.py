from PySide6.QtWidgets import QFrame
from ChargeAutoTool.config import UI

class DashedFrame(QFrame):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"QFrame {{ border: 2px dashed {UI.DASH}; border-radius: 10px; background: #FFFFFF; }}")
