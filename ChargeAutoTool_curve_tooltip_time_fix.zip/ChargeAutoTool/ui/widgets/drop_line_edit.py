from PySide6.QtCore import Signal
from PySide6.QtWidgets import QLineEdit
from ChargeAutoTool.config import UI

class DropLineEdit(QLineEdit):
    dropped = Signal(str)
    def __init__(self, placeholder: str = ""):
        super().__init__()
        self.setPlaceholderText(placeholder)
        self.setAcceptDrops(True)
        self.setStyleSheet(f"QLineEdit {{ border: 2px dashed {UI.DASH}; border-radius: 10px; background: #FFFFFF; }}")
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls(): e.acceptProposedAction()
        else: super().dragEnterEvent(e)
    def dropEvent(self, e):
        if e.mimeData().hasUrls() and e.mimeData().urls():
            p = e.mimeData().urls()[0].toLocalFile()
            if p: self.setText(p); self.dropped.emit(p)
        e.acceptProposedAction()
