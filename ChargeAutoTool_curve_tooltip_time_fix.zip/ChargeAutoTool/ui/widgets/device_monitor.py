from typing import List
from PySide6.QtCore import QTimer, Signal
from PySide6.QtWidgets import QWidget
from ChargeAutoTool.core.adb import list_adb_devices

class DeviceMonitor(QWidget):
    changed = Signal(str, str, list)
    def __init__(self, poll_ms: int = 1200):
        super().__init__()
        self._t = QTimer(self)
        self._t.setInterval(poll_ms)
        self._t.timeout.connect(self._poll)
        self._last: List[str] = []
    def start(self):
        self._t.start(); self._poll()
    def _poll(self):
        devs = list_adb_devices()
        if devs == self._last: return
        self._last = devs
        if len(devs) == 0: self.changed.emit("", "未连接", devs)
        elif len(devs) == 1: self.changed.emit(devs[0], f"已连接：{devs[0]}", devs)
        else: self.changed.emit("", f"多设备在线：{len(devs)}台（请只保留一台）", devs)
