from ChargeAutoTool.config import UI

def build_qss() -> str:
    return f"""
    * {{ font-family: "Segoe UI","Microsoft YaHei","PingFang SC",Arial; color: {UI.TEXT}; }}
    QMainWindow {{ background: {UI.BG}; }}
    QGroupBox {{ background: {UI.CARD}; border: 1px solid {UI.BORDER}; border-radius: {UI.RADIUS}px; margin-top: 10px; padding: 10px; font-weight: 800; }}
    QGroupBox[active="true"] {{ border: 2px solid {UI.PRIMARY}; }}
    QGroupBox::title {{ subcontrol-origin: margin; left: 10px; padding: 0 4px; }}
    QLineEdit {{ background: #fff; border: 1px solid {UI.BORDER}; border-radius: 8px; padding: 0 10px; min-height: {UI.EDIT_H}px; }}

    QTextEdit, QPlainTextEdit {{
      background: #fff;
      border: 1px solid {UI.BORDER};
      border-radius: 8px;
      padding: 8px;
    }}

    QLabel[muted="true"] {{ color: #6B7280; font-weight: 600; }}

    QPushButton {{
      background: {UI.PRIMARY};
      border: 1px solid transparent;
      border-radius: 8px;
      min-height: {UI.BTN_H}px;
      padding: 0 14px;
      font-weight: 700;
      color: white;
    }}
    QPushButton:hover {{ background: {UI.PRIMARY_HOVER}; }}
    QPushButton:pressed {{ background: {UI.PRIMARY_PRESSED}; }}
    QPushButton:disabled {{ background: #CBD5E1; color: #64748B; }}

    QPushButton[role="secondary"] {{
      background: #EEF2F7;
      color: {UI.TEXT};
      border: 1px solid #D2D9E3;
    }}
    /* toggle buttons (mode selection) */
    QPushButton[role="toggle"] {{
      background: #EEF2F7;
      color: {UI.TEXT};
      border: 1px solid #D2D9E3;
      min-height: 28px;
      padding: 0 10px;
      font-weight: 700;
    }}
    QPushButton[role="toggle"]:hover {{ background: #E3EAF3; }}
    QPushButton[role="toggle"]:checked {{
      background: #DDF3E5;
      border: 1px solid #B9DEC8;
      color: #1E6A3A;
    }}

    /* operation buttons (checked = active) */
    QPushButton:checked {{
      border: 1px solid rgba(0,0,0,0.10);
    }}

    /* Tabs highlight */
    QTabBar::tab {{
      background: #EEF2F7;
      border: 1px solid #D2D9E3;
      border-bottom: none;
      padding: 8px 12px;
      border-top-left-radius: 8px;
      border-top-right-radius: 8px;
      margin-right: 6px;
      color: {UI.TEXT};
      font-weight: 700;
    }}
    QTabBar::tab:selected {{
      background: #DDF3E5;
      border: 1px solid #B9DEC8;
      color: #1E6A3A;
    }}
    QTabWidget::pane {{
      border: 1px solid {UI.BORDER};
      border-radius: {UI.RADIUS}px;
      top: -1px;
    }}

    QChartView {{
      background: #fff;
      border: 1px solid {UI.BORDER};
      border-radius: 10px;
    }}

    QPushButton[role="secondary"]:hover {{ background: #E3EAF3; }}
    QPushButton[role="secondary"]:pressed {{ background: #D8E2EF; }}

    QPushButton[role="danger"] {{
      background: #E85D5D;
      border: 1px solid #DC4D4D;
      color: white;
    }}
    QPushButton[role="danger"]:hover {{ background: #DB4F4F; }}
    QPushButton[role="danger"]:pressed {{ background: #C73C3C; }}

    /* success / completed */
    QPushButton[role="success"] {{
      background: #2E7D32;
      border: 1px solid #1B5E20;
      color: white;
    }}
    QPushButton[role="success"]:hover {{ background: #256A28; }}
    QPushButton[role="success"]:pressed {{ background: #1E5A22; }}

    QPushButton[nav="true"] {{
      min-height: 34px;
      padding: 0 10px;
      border-radius: 8px;
      font-weight: 600;
      background: {UI.NAV_IDLE};
      color: {UI.TEXT};
      border: 1px solid #D3D8DE;
    }}
    QPushButton[nav="true"]:hover {{ background: {UI.NAV_IDLE_HOVER}; }}
    QPushButton[nav="true"]:pressed {{ background: #C9CFD7; }}
    QPushButton[nav="true"][active="true"] {{
      background: #DDF3E5;
      border: 1px solid #B9DEC8;
      color: #1E6A3A;
    }}
    """
