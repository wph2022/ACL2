from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Iterable, Iterator, List, Optional, Sequence, Tuple


def _safe_mkdir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


class SqliteLogStore:
    """Row store for parsed logs.

    Design goals:
    - Constant-memory ingestion (streaming inserts)
    - Fast pagination for UI (LIMIT/OFFSET)
    - Stream export without holding rows in RAM

    Schema:
      meta(key TEXT PRIMARY KEY, value TEXT)
      rows(id INTEGER PRIMARY KEY AUTOINCREMENT, c0 TEXT, c1 TEXT, ...)
    """

    def __init__(
        self,
        db_path: Path,
        columns: Sequence[str],
        *,
        mode: str = "rw",  # "rw" or "ro"
    ):
        self.db_path = Path(db_path)
        self.columns = list(columns)
        self._conn: Optional[sqlite3.Connection] = None
        self._col_ids = [f"c{i}" for i in range(len(self.columns))]
        self._mode = mode

        if mode == "rw":
            _safe_mkdir(self.db_path.parent)
            if self.db_path.exists():
                # Safety: don't accidentally append to an existing db.
                self.db_path.unlink(missing_ok=True)

        self._open()
        if mode == "rw":
            self._init_schema()

    def _open(self) -> None:
        if self._mode == "ro":
            uri = f"file:{self.db_path.as_posix()}?mode=ro"
            self._conn = sqlite3.connect(uri, uri=True, check_same_thread=False)
        else:
            self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL;")
        self._conn.execute("PRAGMA synchronous=NORMAL;")
        self._conn.execute("PRAGMA temp_store=MEMORY;")

    def _init_schema(self) -> None:
        assert self._conn is not None
        self._conn.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);")
        self._conn.execute("DELETE FROM meta;")
        self._conn.execute(
            "INSERT INTO meta(key,value) VALUES('columns', ?)",
            ("\t".join(self.columns),),
        )
        cols_sql = ",".join([f"{cid} TEXT" for cid in self._col_ids])
        self._conn.execute(f"CREATE TABLE IF NOT EXISTS rows (id INTEGER PRIMARY KEY AUTOINCREMENT, {cols_sql});")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_rows_id ON rows(id);")
        self._conn.commit()

    @classmethod
    def open_existing(cls, db_path: Path) -> "SqliteLogStore":
        # Read columns from meta
        conn = sqlite3.connect(f"file:{Path(db_path).as_posix()}?mode=ro", uri=True, check_same_thread=False)
        try:
            cur = conn.execute("SELECT value FROM meta WHERE key='columns' LIMIT 1;")
            row = cur.fetchone()
            if not row:
                raise RuntimeError("Invalid store: missing meta.columns")
            columns = row[0].split("\t") if row[0] else []
        finally:
            conn.close()
        return cls(Path(db_path), columns, mode="ro")

    def close(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            finally:
                self._conn = None

    def commit(self) -> None:
        if self._conn is not None:
            self._conn.commit()

    def insert_many(self, rows: Sequence[Sequence[str]]) -> None:
        if not rows:
            return
        assert self._conn is not None
        ph = ",".join(["?"] * len(self.columns))
        sql = f"INSERT INTO rows({','.join(self._col_ids)}) VALUES({ph});"
        self._conn.executemany(sql, rows)

    def count(self) -> int:
        assert self._conn is not None
        cur = self._conn.execute("SELECT COUNT(1) FROM rows;")
        v = cur.fetchone()[0]
        return int(v or 0)

    def fetch(self, offset: int, limit: int) -> List[Tuple[str, ...]]:
        assert self._conn is not None
        sql = f"SELECT {','.join(self._col_ids)} FROM rows ORDER BY id LIMIT ? OFFSET ?;"
        cur = self._conn.execute(sql, (int(limit), int(offset)))
        out = []
        for r in cur.fetchall():
            out.append(tuple("" if x is None else str(x) for x in r))
        return out

    def iter_all(self, batch_size: int = 5000) -> Iterator[List[Tuple[str, ...]]]:
        """Yield batches of rows for streaming export."""
        total = self.count()
        off = 0
        while off < total:
            batch = self.fetch(off, batch_size)
            if not batch:
                break
            yield batch
            off += len(batch)
