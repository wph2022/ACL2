# -*- coding: utf-8 -*-
"""Event bus (very small) for decoupling UI <-> modules.

Design goals:
- Minimal footprint (no new dependencies)
- Thread-safe publish via Qt signal delivery
- Topic-based routing so modules do not import each other

Usage:
    bus.publish('log.data_ready', result=...)
    bus.subscribe('log.data_ready', handler)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List

from PySide6.QtCore import QObject, Signal


Handler = Callable[[Dict[str, Any]], None]


@dataclass
class _Subscription:
    topic: str
    handler: Handler


class EventBus(QObject):
    """A tiny topic-based event bus.

    Internally it emits a Qt signal so that handlers are executed in the
    receiver's thread (typically the UI thread).
    """

    _sig = Signal(str, object)  # (topic, payload_dict)

    def __init__(self, parent: QObject | None = None):
        super().__init__(parent)
        self._subs: List[_Subscription] = []
        self._sig.connect(self._dispatch)

    def subscribe(self, topic: str, handler: Handler) -> None:
        self._subs.append(_Subscription(topic=topic, handler=handler))

    def publish(self, topic: str, **payload: Any) -> None:
        # Emit once; dispatch will fan out.
        self._sig.emit(topic, dict(payload))

    # ----------------------
    # Internal
    # ----------------------
    def _dispatch(self, topic: str, payload: object) -> None:
        if not isinstance(payload, dict):
            payload = {"data": payload}
        for sub in list(self._subs):
            if sub.topic == topic:
                try:
                    sub.handler(payload)  # type: ignore[arg-type]
                except Exception:
                    # Never let bus exceptions crash the app.
                    # The global exception hook/logger should capture details.
                    pass
