"""Application-level primitives.

Keep this package minimal and stable: modules should depend on it, but it should
not depend on feature modules.
"""
