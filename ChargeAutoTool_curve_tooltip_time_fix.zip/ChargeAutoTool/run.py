#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
from pathlib import Path

# 允许在包目录内直接执行：python run.py
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication
from ChargeAutoTool.ui.styles import build_qss
from ChargeAutoTool.ui.main_window import MainWindow
from ChargeAutoTool.utils.logger import get_app_logger, install_global_exception_hooks
from ChargeAutoTool.utils.resources import resource_path


def main() -> int:
    log_dir = Path(__file__).resolve().parent / "LOGS"
    logger = get_app_logger(log_dir)
    install_global_exception_hooks(logger)
    logger.info("应用启动")
    print("[INFO] ACL 启动中... (详细日志见 LOGS/app.log)")

    app = QApplication(sys.argv)
    icon_file = resource_path("assets/icons/acl.png")
    if icon_file.exists():
        app.setWindowIcon(QIcon(str(icon_file)))

    app.setStyleSheet(build_qss())
    try:
        w = MainWindow()
    except Exception as e:
        logger.exception("主窗口初始化失败")
        print("[ERROR] 主窗口初始化失败，详情见 LOGS/app.log", file=sys.stderr)
        raise
    if icon_file.exists():
        w.setWindowIcon(QIcon(str(icon_file)))
    w.show()
    code = app.exec()
    logger.info("应用退出 code=%s", code)
    print(f"[INFO] ACL 已退出 code={code} (详细日志见 LOGS/app.log)")
    return code


if __name__ == "__main__":
    raise SystemExit(main())