import sys
from pathlib import Path


def resource_path(relative: str) -> Path:
    """Resolve resources both in source tree and PyInstaller bundle."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / relative
    return Path(__file__).resolve().parents[2] / relative
