import os
import subprocess
from typing import List, Tuple


def _windows_no_console_kwargs() -> dict:
    """Return subprocess kwargs that suppress extra cmd windows on Windows."""
    if os.name != "nt":
        return {}

    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    return {
        "creationflags": subprocess.CREATE_NO_WINDOW,
        "startupinfo": startupinfo,
    }


def run_cmd(cmd: List[str], timeout: int = 10) -> Tuple[int, str, str]:
    try:
        p = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            **_windows_no_console_kwargs(),
        )
        return p.returncode, (p.stdout or "").rstrip(), (p.stderr or "").rstrip()
    except Exception as e:
        return 999, "", str(e)
