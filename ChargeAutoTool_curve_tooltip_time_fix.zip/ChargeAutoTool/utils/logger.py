from __future__ import annotations

import logging
import sys
import threading
from logging.handlers import RotatingFileHandler
from pathlib import Path


_LOGGER_NAME = "ChargeAutoTool"


def _build_logger(log_dir: Path) -> logging.Logger:
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(_LOGGER_NAME)
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    file_handler = RotatingFileHandler(
        log_dir / "app.log",
        maxBytes=2 * 1024 * 1024,
        backupCount=10,
        encoding="utf-8",
    )
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # Also log to console (useful when running from cmd/terminal)
    stream_handler = logging.StreamHandler(sys.stderr)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    logger.propagate = False
    return logger


def get_app_logger(log_dir: Path) -> logging.Logger:
    return _build_logger(log_dir)


def install_global_exception_hooks(logger: logging.Logger) -> None:
    def _sys_hook(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logger.exception("未捕获异常", exc_info=(exc_type, exc_value, exc_traceback))

        # Ensure users see something in console even if UI fails to show
        try:
            import traceback
            traceback.print_exception(exc_type, exc_value, exc_traceback, file=sys.stderr)
        except Exception:
            pass

    sys.excepthook = _sys_hook

    if hasattr(threading, "excepthook"):
        def _threading_hook(args):
            logger.exception(
                "线程未捕获异常: thread=%s",
                getattr(args.thread, "name", "unknown"),
                exc_info=(args.exc_type, args.exc_value, args.exc_traceback),
            )

        threading.excepthook = _threading_hook


class UILogger:
    def __init__(self, log_dir: Path):
        self.log_dir = log_dir
        self._logger = get_app_logger(log_dir)

    def write(self, msg: str):
        self._logger.info(msg.rstrip())

    def error(self, msg: str):
        self._logger.error(msg.rstrip())

    def exception(self, msg: str):
        self._logger.exception(msg.rstrip())
