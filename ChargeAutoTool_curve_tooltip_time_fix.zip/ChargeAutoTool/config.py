from dataclasses import dataclass

@dataclass(frozen=True)
class UI:
    LEFT_RATIO:int=30
    RIGHT_RATIO:int=70
    BTN_H:int=30
    EDIT_H:int=32
    GAP:int=10
    PAD:int=12
    RADIUS:int=10

    PRIMARY:str="#4CAF50"
    PRIMARY_HOVER:str="#43A047"
    PRIMARY_PRESSED:str="#388E3C"
    BG:str="#F5F5F5"
    CARD:str="#FFFFFF"
    BORDER:str="#DADCE0"
    TEXT:str="#202124"
    MUTED:str="#5F6368"
    DASH:str="#BDBDBD"
    LOG_BG:str="#F1F3F4"
    NAV_IDLE:str="#E0E0E0"
    NAV_IDLE_HOVER:str="#D5D5D5"
    NAV_FONT_PT:int=10


from pathlib import Path

@dataclass(frozen=True)
class PATHS:
    """Default local paths used when UI does not expose directory selection."""
    # Root under project LOGS directory
    ROOT: Path = Path(__file__).resolve().parent / "LOGS"
    STORE_DIR: Path = ROOT / "store"
    EXPORT_DIR: Path = ROOT / "exports"


# =========================
# Online log export defaults
# =========================

# Default remote directory pulled from device for "在线日志导出并分析".
# (Matches the original ACL tool behavior.)
ADB_REMOTE_LOG_DIR: str = "/sdcard/mtklog/mobilelog"

