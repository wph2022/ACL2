import datetime as dt
from pathlib import Path
from typing import Optional, Dict

from PySide6.QtCore import QEvent, Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QGroupBox, QGridLayout, QPushButton,
    QFileDialog, QMessageBox, QHBoxLayout, QMenu
)

from ChargeAutoTool.config import UI, PATHS, ADB_REMOTE_LOG_DIR
from ChargeAutoTool.ui.widgets.drop_line_edit import DropLineEdit
from ChargeAutoTool.ui.widgets.dashed_frame import DashedFrame
from ChargeAutoTool.modules.log_analysis.parsers import HealthdParser, VbatParser
from ChargeAutoTool.modules.log_analysis.analyzer import LogAnalyzer, ParseResult
from ChargeAutoTool.modules.log_analysis.workers import MultiAnalysisWorker, CsvExportWorker, XlsxExportWorker, AdbPullWorker
from ChargeAutoTool.modules.ai_analysis.service import AnalyzeRequest, DEFAULT_PROFILE
from ChargeAutoTool.modules.ai_analysis.workers import AiAnalyzeWorker
from ChargeAutoTool.modules.log_analysis.results import LogResults
from ChargeAutoTool.core.settings import AppSettings


class LogControls(QWidget):
    """日志分析（自动解析 Healthd + Vbat）并集成 AI 协议分析。"""

    def __init__(self, host):
        super().__init__()
        self.host = host
        self.analyzer = LogAnalyzer()
        self.p_healthd = HealthdParser()
        self.p_vbat = VbatParser()

        self.settings = AppSettings()

        self.results: Optional[LogResults] = None
        self.w_an: Optional[MultiAnalysisWorker] = None
        self.w_ai: Optional[AiAnalyzeWorker] = None
        self.w_csv: Optional[CsvExportWorker] = None
        self.w_pull: Optional[AdbPullWorker] = None

        self.cur: Dict[str, ParseResult] = {}
        self._mode: str = "local"   # local | online
        self._active_op: str = ""   # analyze | ai | csv
        self._build()

    def attach_results(self, r: LogResults):
        self.results = r

    def set_device_status(self, s: str):
        """由主窗口的设备监控回调更新。"""
        try:
            self.dev_label.setText(s)
        except Exception:
            pass

    def _log(self, msg: str):
        self.results and self.results.append_log(msg)

    def _op(self, msg: str):
        hasattr(self.host, "log_operation") and self.host.log_operation(f"[日志分析] {msg}")

    def _busy(self, b: bool):
        for w in (
            self.outdir,
            self.pick_out,
            self.path,
            self.pick_path,
            self.btn_an,
            self.btn_ai,
            self.btn_csv,
            self.btn_cl,
            self.grp_online,
            self.grp_local,
        ):
            w.setEnabled(not b)

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(UI.GAP)

        title = QLabel("ACL 日志分析")
        root.addWidget(title)

        # 模式选择：直接点击「在线日志分析 / 本地日志分析」框本身（更直觉）

        # ============== 在线日志分析（保留展示与导出目录选择；不在此处触发导出并分析） ==============
        online = QGroupBox("在线日志分析")
        self.grp_online = online
        online.setProperty("clickable", "true")
        online.installEventFilter(self)
        online.setCursor(Qt.PointingHandCursor)
        og = QGridLayout(online)
        og.setHorizontalSpacing(8)
        og.setVerticalSpacing(8)
        og.setColumnStretch(1, 1)

        devf = DashedFrame()
        dl = QHBoxLayout(devf)
        dl.setContentsMargins(10, 6, 10, 6)
        self.dev_label = QLabel("未连接")
        dl.addWidget(self.dev_label, 1)

        self.outdir = DropLineEdit("选择导出目录")
        self.pick_out = QPushButton("选择目录")
        self.pick_out.setProperty("role", "secondary")
        self.pick_out.clicked.connect(self._pick_out)

        og.addWidget(QLabel("设备："), 0, 0)
        og.addWidget(devf, 0, 1, 1, 2)
        og.addWidget(QLabel("输出目录"), 1, 0)
        og.addWidget(self.outdir, 1, 1)
        og.addWidget(self.pick_out, 1, 2)
        root.addWidget(online)

        # ============================ 本地日志分析（保留路径选择） ============================
        local = QGroupBox("本地日志分析")
        self.grp_local = local
        local.setProperty("clickable", "true")
        local.installEventFilter(self)
        local.setCursor(Qt.PointingHandCursor)
        lg = QGridLayout(local)
        lg.setHorizontalSpacing(8)
        lg.setVerticalSpacing(8)
        lg.setColumnStretch(0, 1)

        self.path = DropLineEdit("拖拽文件/文件夹到这里，或点击“选择”")
        self.pick_path = QPushButton("选择文件/文件夹")
        self.pick_path.setProperty("role", "secondary")
        self.pick_path.clicked.connect(self._show_pick_menu)

        lg.addWidget(self.path, 0, 0)
        lg.addWidget(self.pick_path, 0, 1)
        root.addWidget(local)

        # ===================================== 操作区 =====================================
        box = QGroupBox("操作区")
        g = QGridLayout(box)
        g.setHorizontalSpacing(8)
        g.setVerticalSpacing(8)
        g.setColumnStretch(1, 1)

        self.btn_an = QPushButton("日志分析")
        self.btn_an.setCheckable(True)
        self.btn_an.clicked.connect(self.on_log_action)

        self.btn_ai = QPushButton("AI协议分析")
        self.btn_ai.setProperty("role", "secondary")
        self.btn_ai.setCheckable(True)
        self.btn_ai.clicked.connect(self.on_ai_analyze)

        self.btn_csv = QPushButton("导出CSV/Excel")
        self.btn_csv.setProperty("role", "secondary")
        self.btn_csv.setCheckable(True)
        self.btn_csv.setEnabled(False)
        self.btn_csv.clicked.connect(self.on_export)

        self.btn_cl = QPushButton("清除")
        self.btn_cl.setProperty("role", "danger")
        self.btn_cl.clicked.connect(self.on_clear)

        g.addWidget(self.btn_an, 0, 0)
        g.addWidget(self.btn_ai, 0, 1)
        g.addWidget(self.btn_csv, 0, 2)
        g.addWidget(self.btn_cl, 1, 0, 1, 3)
        root.addWidget(box)
        root.addStretch(1)

        # restore settings
        lp = self.settings.get_str(self.settings.keys.last_log_path, "")
        if lp:
            self.path.setText(lp)
        od = self.settings.get_str(self.settings.keys.last_export_dir, "")
        if od:
            self.outdir.setText(od)

        # default mode
        self._set_mode("local")

    # -------------------- task submission (minimal integration) --------------------
    def _submit(self, name: str, worker):
        """Submit a QThread worker via TaskRunner if available."""
        tr = getattr(self.host, "task_runner", None)
        if tr is not None:
            try:
                tr.submit(name, worker)
                return
            except Exception:
                # fall back to direct start
                pass
        worker.start()

    def eventFilter(self, obj, event):
        if event.type() == QEvent.MouseButtonPress:
            if obj is getattr(self, "grp_online", None):
                self._set_mode("online")
                return True
            if obj is getattr(self, "grp_local", None):
                self._set_mode("local")
                return True
        return super().eventFilter(obj, event)

    # -------------------- visual states --------------------
    def _set_group_active(self, w: QGroupBox, active: bool):
        try:
            w.setProperty("active", "true" if active else "false")
            w.style().unpolish(w); w.style().polish(w)
        except Exception:
            pass

    def _set_mode(self, mode: str):
        if mode not in ("online", "local"):
            return
        self._mode = mode

        self._set_group_active(self.grp_online, mode == "online")
        self._set_group_active(self.grp_local, mode == "local")

        # enable relevant inputs
        online_on = mode == "online"
        for w in (self.outdir, self.pick_out):
            w.setEnabled(online_on)
        for w in (self.path, self.pick_path):
            w.setEnabled(not online_on)

        # right side hint
        # NOTE: do not auto-switch right tabs on mode change.

    def _set_active_op(self, op: str):
        self._active_op = op
        try:
            self.btn_an.setChecked(op == "analyze")
            self.btn_ai.setChecked(op == "ai")
            self.btn_csv.setChecked(op == "csv")
        except Exception:
            pass

        # NOTE: do not auto-switch right tabs on operation selection.

    def _pick_out(self):
        dp = QFileDialog.getExistingDirectory(self, "选择导出目录")
        if dp:
            self.outdir.setText(dp)
            self.settings.set_str(self.settings.keys.last_export_dir, dp)

    def _show_pick_menu(self):
        m = QMenu(self)
        act_file = m.addAction("选择文件…")
        act_dir = m.addAction("选择文件夹…")
        chosen = m.exec(self.pick_path.mapToGlobal(self.pick_path.rect().bottomLeft()))
        if chosen == act_file:
            self._pick_file()
        elif chosen == act_dir:
            self._pick_dir()

    def _pick_file(self):
        fp, _ = QFileDialog.getOpenFileName(
            self,
            "选择日志文件",
            "",
            "Log (*.log *.txt *.out *.csv *.gz *.zip);;All(*.*)"
        )
        if fp:
            self.path.setText(fp)
            self.settings.set_str(self.settings.keys.last_log_path, fp)

    def _pick_dir(self):
        dp = QFileDialog.getExistingDirectory(self, "选择日志目录")
        if dp:
            self.path.setText(dp)
            self.settings.set_str(self.settings.keys.last_log_path, dp)

    def _ensure_dirs(self):
        try:
            PATHS.ROOT.mkdir(parents=True, exist_ok=True)
            PATHS.STORE_DIR.mkdir(parents=True, exist_ok=True)
            PATHS.EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    def on_clear(self):
        self.path.setText("")
        self.cur = {}
        if self.results:
            self.results.clear_all()
        self.btn_csv.setEnabled(False)
        self._set_active_op("")

    # -------------------- log analyze --------------------
    def on_log_action(self):
        """统一入口：在线模式=导出在线日志并分析；本地模式=直接分析。"""
        self._set_active_op("analyze")
        if self._mode == "online":
            self.on_pull_analyze()
            return
        self.on_analyze()

    def on_analyze(self):
        p = Path(self.path.text().strip())
        if not p.exists():
            QMessageBox.warning(self, "提示", "路径不存在")
            return
        if self.w_an and self.w_an.isRunning():
            return

        self._ensure_dirs()
        self.cur = {}

        if self.results:
            self.results.clear_tables()
            self.results.append_log(f"[INFO] 输入：{p}\n")

        self._busy(True)
        self.btn_csv.setEnabled(False)

        self.w_an = MultiAnalysisWorker(
            self.analyzer,
            p,
            [self.p_healthd, self.p_vbat],
            store_dir=PATHS.STORE_DIR,
        )
        self.w_an.log_signal.connect(lambda s: self._log(s))
        self.w_an.init_cols_signal.connect(self._on_init_cols)
        self.w_an.batch_rows_signal.connect(self._on_batch_rows)
        self.w_an.result_signal.connect(self._on_results)
        self.w_an.finished_signal.connect(lambda: self._on_an_finished())
        self._op(f"开始解析 path={p}")
        self._submit("日志分析", self.w_an)

    def _on_init_cols(self, payload):
        try:
            parser_name, cols = payload
            self.results and self.results.set_cols(parser_name, list(cols))
        except Exception:
            pass

    def _on_batch_rows(self, payload):
        try:
            parser_name, rows = payload
            self.results and self.results.append_rows(parser_name, rows)
        except Exception:
            pass

    def _on_results(self, res_map: dict):
        # res_map: parser_name -> ParseResult
        try:
            self.cur = dict(res_map or {})
            ok = False
            for r in self.cur.values():
                if getattr(r, "parsed_rows", 0) > 0 and getattr(r, "store_path", ""):
                    ok = True
            self.btn_csv.setEnabled(ok)
            try:
                if self.results:
                    self.results.set_curve_sources(self.cur)
            except Exception:
                pass

            # decoupled event for future modules (report/AI/automation)
            bus = getattr(self.host, "bus", None)
            if bus is not None:
                try:
                    bus.publish("log.data_ready", parsers=list(self.cur.keys()))
                except Exception:
                    pass
        except Exception:
            self.btn_csv.setEnabled(False)

    def _on_an_finished(self):
        self._busy(False)
        self._op("解析完成")
        # NOTE: keep right tab unchanged.

    # -------------------- AI analyze --------------------
    def on_ai_analyze(self):
        self._set_active_op("ai")
        p = Path(self.path.text().strip())
        if not p.exists():
            QMessageBox.warning(self, "提示", "路径不存在")
            return
        if self.w_ai and self.w_ai.isRunning():
            return

        if self.results:
            self.results.append_log("[INFO] ===== 开始 AI 协议分析 =====\n")

        # UI hint: running
        try:
            self.btn_ai.setText("AI协议分析(进行中…)")
            self.btn_ai.setProperty("role", "secondary")
            self.btn_ai.style().unpolish(self.btn_ai); self.btn_ai.style().polish(self.btn_ai)
        except Exception:
            pass

        self._busy(True)
        self._ensure_dirs()

        req = AnalyzeRequest(input_path=str(p), profile=DEFAULT_PROFILE.name)
        self.w_ai = AiAnalyzeWorker(req)
        self.w_ai.progress.connect(lambda s: self.results and self.results.append_log(s))
        self.w_ai.failed.connect(self._on_ai_fail)
        self.w_ai.result.connect(self._on_ai_result)
        self.w_ai.finished.connect(lambda: self._on_ai_finished())
        self._op(f"开始AI协议分析 path={p}")
        self._submit("AI协议分析", self.w_ai)

    def _on_ai_fail(self, err: str):
        self.results and self.results.append_log(f"[ERROR] AI协议分析失败：{err}\n")
        self._op(f"AI协议分析失败 err={err.splitlines()[0] if err else 'unknown'}")

    def _on_ai_result(self, payload: dict):
        if self.results:
            self.results.set_ai_payload(payload)
            self.results.append_log("[INFO] AI 协议分析完成\n")
            # NOTE: do not auto-switch right tabs after results are ready.

        # UI hint: completed (green)
        try:
            self.btn_ai.setText("AI协议分析(完成)")
            self.btn_ai.setProperty("role", "success")
            self.btn_ai.style().unpolish(self.btn_ai); self.btn_ai.style().polish(self.btn_ai)
        except Exception:
            pass

        bus = getattr(self.host, "bus", None)
        if bus is not None:
            try:
                bus.publish("ai.result_ready")
            except Exception:
                pass

    def _on_ai_finished(self):
        self._busy(False)

    # -------------------- online export + analyze --------------------
    def on_pull_analyze(self):
        serial = getattr(self.host, "device_serial", lambda: "")()
        outdir = self.outdir.text().strip()
        if not outdir:
            # fall back to default exports directory
            outdir = str(PATHS.EXPORT_DIR)
            self.outdir.setText(outdir)
        if not serial or not outdir:
            QMessageBox.warning(self, "提示", "请检查设备连接与导出目录")
            return
        if self.w_pull and self.w_pull.isRunning():
            return

        self._ensure_dirs()
        self.settings.set_str(self.settings.keys.last_export_dir, outdir)

        if self.results:
            self.results.append_log(f"[INFO] ===== 在线导出并分析 =====\n")
            self.results.append_log(f"[INFO] serial={serial}\n")
            self.results.append_log(f"[INFO] remote={ADB_REMOTE_LOG_DIR}\n")
            self.results.append_log(f"[INFO] outdir={outdir}\n")

        self._busy(True)
        self._op(f"开始在线导出并分析 serial={serial}, outdir={outdir}")
        self.w_pull = AdbPullWorker(serial, ADB_REMOTE_LOG_DIR, outdir)
        self.w_pull.log_signal.connect(lambda s: self._log(s))
        self.w_pull.done_signal.connect(self._on_pull_done)
        self.w_pull.finished.connect(lambda: None)
        self._submit("在线导出", self.w_pull)

    def _on_pull_done(self, ok: bool, msg: str):
        if not ok:
            self._busy(False)
            self._op(f"在线导出失败 msg={msg}")
            QMessageBox.critical(self, "导出失败", msg)
            return
        # msg is the local directory path
        self._op(f"在线导出完成 path={msg}")
        self.path.setText(msg)
        # continue with normal analysis
        self._busy(False)
        self.on_analyze()

    # -------------------- export csv --------------------
    def on_export(self):
        self._set_active_op("csv")
        if not self.cur:
            return
        self._ensure_dirs()

        # Export as ONE workbook with 2 sheets (Healthd/Vbat) to avoid multiple CSV files.
        now = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        xlsx_fp = str(PATHS.EXPORT_DIR / f"log_export_{now}.xlsx")

        sheets = []
        for name, res in (self.cur or {}).items():
            store_path = getattr(res, "store_path", "")
            cols = getattr(res, "columns", []) or []
            rows = getattr(res, "parsed_rows", None)
            # Export as long as we have a store path + columns. Even if parsed_rows is 0/None,
            # we still export an empty sheet with header for consistency (Healthd + Vbat).
            if not store_path or not cols:
                continue

            if "health" in name.lower():
                sheet_name = "Healthd"
            elif "vbat" in name.lower():
                sheet_name = "Vbat"
            else:
                sheet_name = name
            sheets.append((sheet_name, store_path, list(cols)))

        # Prefer stable order: Healthd then Vbat.
        order = {"Healthd": 0, "Vbat": 1}
        sheets.sort(key=lambda x: order.get(x[0], 9))

        if not sheets:
            QMessageBox.information(self, "提示", "暂无可导出的数据")
            return

        self._busy(True)
        self.w_csv = XlsxExportWorker(xlsx_fp, sheets)
        self.w_csv.log_signal.connect(lambda s: self._log(s))
        self.w_csv.done_signal.connect(lambda ok, fp: self._on_export_done(ok, fp))
        self.w_csv.finished.connect(lambda: self._busy(False))
        self._submit("导出Excel", self.w_csv)

    def _start_next_export(self):
        # kept for backward compatibility (no-op)
        self._busy(False)
        return

    def _on_export_done(self, ok: bool, fp: str):
        if ok:
            self._log(f"[INFO] 导出完成：{fp}\n")
            self._op(f"导出 ok fp={fp}")
        else:
            self._log(f"[ERROR] 导出失败：{fp}\n")
            self._op(f"导出 failed fp={fp}")

        bus = getattr(self.host, "bus", None)
        if bus is not None:
            try:
                bus.publish("export.done", ok=bool(ok), path=str(fp))
            except Exception:
                pass