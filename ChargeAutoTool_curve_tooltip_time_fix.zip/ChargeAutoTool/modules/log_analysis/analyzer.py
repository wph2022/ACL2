import os, re
import datetime as dt
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple
from ChargeAutoTool.core.time_sync import TimeSyncEstimator
from ChargeAutoTool.core.base_parser import BaseLogParser
from ChargeAutoTool.infrastructure.log_store_sqlite import SqliteLogStore
from ChargeAutoTool.modules.log_analysis.parsers import HealthdParser

LOG_EXTS={".log",".txt",".out",".csv"}
SKIP_DIRS={".git",".svn","__pycache__","node_modules","images","image","img","video","videos","media","cache","caches","tmp","temp","download","downloads","apks","apk","obb","dcim","pictures","movies","music"}
NAME_KEYWORDS=("logcat","bugreport","tombstone","anr","dropbox","kmsg","kernel")
MAX_UI_ROWS=5000; MAX_DYNAMIC_COLS=40; MAX_SCAN_LINES=10000000; MAX_TABLE_ROWS=500000
PRE_COLLECT_MATCHES=500
PRE_COLLECT_LINES=200000
STREAM_BATCH_SIZE=200

@dataclass
class ParseResult:
    parser_name: str
    source: str
    files_scanned: int
    lines_scanned: int
    matched_lines: int
    parsed_rows: int
    columns: List[str]
    preview_rows: List[Tuple[str, ...]]
    store_path: str  # sqlite file path

class LogAnalyzer:
    def __init__(self):
        self.log_message=lambda m: None
        self.ts=TimeSyncEstimator()
    def _iter(self,fp:Path)->Iterable[str]:
        try:
            with fp.open("r",encoding="utf-8",errors="replace") as f: yield from f
        except Exception as e: self.log_message(f"[WARN] 无法读取文件：{fp} ({e})\n")
    @staticmethod
    def _is_k(ts:str)->bool:
        ts=ts.strip()
        if not ts or any(ch in ts for ch in "-:"): return False
        try: float(ts); return True
        except Exception: return False
    def _apply_ts(self,row:Dict[str,str])->None:
        ts=row.get("timestamp","").strip()
        if not ts: return
        if not self._is_k(ts): row["android_time"]=ts; return
        row["kernel_ts"]=ts
        if self.ts.offset_seconds is None: return
        try: at=self.ts.k2a(float(ts))
        except Exception: return
        if at: row["android_time"]=at
    @staticmethod
    def _nkey(s:str):
        ps=re.split(r"(\d+)",s); return [int(p) if p.isdigit() else p.lower() for p in ps]
    def _collect(self,path:Path)->List[Path]:
        if path.is_file(): return [path]
        base=path; ml=base/"mobilelog"; root=ml if ml.exists() and ml.is_dir() else base
        out=[]
        for r,dirs,files in os.walk(root,topdown=True):
            dirs[:]=[d for d in dirs if d.lower() not in SKIP_DIRS]
            for fn in files:
                p=Path(r)/fn
                if p.suffix.lower() in LOG_EXTS or any(k in fn.lower() for k in NAME_KEYWORDS): out.append(p)
        try: out.sort(key=lambda x:self._nkey(str(x.relative_to(root)).replace("\\","/")))
        except Exception: out.sort(key=lambda x:self._nkey(str(x)))
        return out
    def _infer_cols_stream(self, parser: BaseLogParser, files: List[Path]) -> List[str]:
        if hasattr(parser, "base_keys") and getattr(parser, "base_keys"):
            return ["android_time", "kernel_ts", "log_type"] + [k for k in parser.base_keys if k not in ("android_time","kernel_ts","log_type")] + ["log_file"]
        seen = set(["android_time", "kernel_ts", "log_type", "log_file", "timestamp"])
        dyn: List[str] = []; lines = 0; matches = 0
        for fp in files:
            for line in self._iter(fp):
                lines += 1
                if lines >= PRE_COLLECT_LINES: break
                if not parser.match(line): continue
                row = parser.parse_line(line)
                if not row: continue
                matches += 1
                for k in row.keys():
                    if k in seen: continue
                    seen.add(k); dyn.append(k)
                    if len(dyn) >= MAX_DYNAMIC_COLS: break
                if matches >= PRE_COLLECT_MATCHES or len(dyn) >= MAX_DYNAMIC_COLS: break
            if lines >= PRE_COLLECT_LINES or matches >= PRE_COLLECT_MATCHES or len(dyn) >= MAX_DYNAMIC_COLS: break
        return ["android_time", "kernel_ts", "log_type"] + dyn + ["log_file"]

    def analyze_stream(
        self,
        path: Path,
        parser: BaseLogParser,
        *,
        store_dir: Path,
        on_init_cols=None,
        on_batch=None,
        cancel_flag=None,
    ) -> ParseResult:
        files = self._collect(path)
        self.log_message(f"[INFO] 扫描文件数：{len(files)}\n")
        self.ts.fit(files, log=self.log_message)
        cols = self._infer_cols_stream(parser, files)
        if on_init_cols: on_init_cols(cols)

        # sqlite store (streaming)
        store_dir = Path(store_dir)
        store_dir.mkdir(parents=True, exist_ok=True)
        ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        db_path = store_dir / f"ACL_{parser.log_type}_{ts}.sqlite"
        store = SqliteLogStore(db_path, cols, mode="rw")

        preview_rows: List[Tuple[str, ...]] = []
        insert_buf: List[Tuple[str, ...]] = []
        batch: List[Tuple[str, ...]] = []
        lines = 0
        matched = 0
        parsed = 0
        for fp in files:
            for line in self._iter(fp):
                lines += 1
                if lines >= MAX_SCAN_LINES: break
                if cancel_flag is not None and getattr(cancel_flag, "cancelled", False):
                    self.log_message("[WARN] 用户取消任务。\n")
                    store.commit(); store.close()
                    return ParseResult(parser.log_type, str(path), len(files), lines, matched, parsed, cols, preview_rows, str(db_path))
                if not parser.match(line): continue
                row = parser.parse_line(line)
                if not row: continue
                matched += 1
                row.setdefault("log_file", fp.name)
                self._apply_ts(row)
                trow = tuple(str(row.get(c, "")) for c in cols)
                insert_buf.append(trow)
                parsed += 1

                # streaming insert
                if len(insert_buf) >= 2000:
                    store.insert_many(insert_buf)
                    store.commit()
                    insert_buf.clear()

                # UI preview (only first MAX_UI_ROWS)
                if len(preview_rows) < MAX_UI_ROWS:
                    preview_rows.append(trow)
                    batch.append(trow)
                    if len(batch) >= STREAM_BATCH_SIZE and on_batch: on_batch(batch); batch = []

                if parsed >= MAX_TABLE_ROWS:
                    break
            if lines >= MAX_SCAN_LINES or parsed >= MAX_TABLE_ROWS:
                break
        if batch and on_batch: on_batch(batch)

        if insert_buf:
            store.insert_many(insert_buf)
            store.commit()
            insert_buf.clear()
        store.close()

        return ParseResult(parser.log_type, str(path), len(files), lines, matched, parsed, cols, preview_rows, str(db_path))
