import re
from typing import Dict
from ChargeAutoTool.core.base_parser import BaseLogParser

class HealthdParser(BaseLogParser):
    log_type="healthd"; keyword="healthd: battery l="
    base_keys=["l","v","t","h","st","c","fc","cc","chg"]
    _re=re.compile(r"healthd:\s*battery\s+(.*)",re.I)
    _split=re.compile(r"[\s,]+")
    _re_kmsg=re.compile(r"<\d+>\[\s*(\d+(?:\.\d+)?)\s*\]")
    def parse_line(self,line:str)->Dict[str,str]:
        ts=self.ts(line)
        if not ts:
            m2=self._re_kmsg.search(line)
            if m2: ts=m2.group(1)
        m=self._re.search(line)
        if not m: return {}
        kv={}
        for tok in self._split.split(m.group(1).strip()):
            if not tok: continue
            if ":" in tok: k,v=tok.split(":",1)
            elif "=" in tok: k,v=tok.split("=",1)
            else: continue
            if k.strip(): kv[k.strip()]=v.strip()
        out={k:kv.get(k,"") for k in self.base_keys}
        out.update({"timestamp":ts,"log_type":self.log_type})
        return out

class VbatParser(BaseLogParser):
    log_type="vbat"; keyword="]Vbat="
    _split=re.compile(r"[\s,]+")
    def parse_line(self,line:str)->Dict[str,str]:
        ts=self.ts(line)
        idx=line.find("Vbat=")
        if idx<0: idx=line.find("VBat=")
        if idx<0: return {}
        kv={}
        for tok in self._split.split(line[idx:].strip()):
            if not tok: continue
            if ":" in tok: k,v=tok.split(":",1)
            elif "=" in tok: k,v=tok.split("=",1)
            else: continue
            if k.strip(): kv[k.strip()]=v.strip()
        if not kv: return {}
        kv.update({"timestamp":ts,"log_type":self.log_type})
        return kv
