from __future__ import annotations

from typing import List, Tuple, Dict
from pathlib import Path

from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex, QTimer, QPointF, QMargins
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QTabWidget, QTableView, QTextEdit, QHeaderView,
    QLabel, QTableWidget, QTableWidgetItem, QPlainTextEdit, QSizePolicy,
    QStackedLayout, QHBoxLayout, QPushButton, QCheckBox, QStackedWidget
)

from PySide6.QtCharts import QChart, QChartView, QLineSeries, QValueAxis, QCategoryAxis
from PySide6.QtGui import QPainter, QColor, QPen, QBrush

from ChargeAutoTool.infrastructure.log_store_sqlite import SqliteLogStore
from ChargeAutoTool.config import UI


class LogTableModel(QAbstractTableModel):
    def __init__(self):
        super().__init__()
        self._cols: List[str] = []
        self._rows: List[Tuple[str, ...]] = []

    def set_data(self, cols: List[str], rows: List[Tuple[str, ...]]):
        self.beginResetModel()
        self._cols = list(cols)
        self._rows = list(rows)
        self.endResetModel()

    def append_rows(self, rows: List[Tuple[str, ...]]):
        if not rows:
            return
        s = len(self._rows)
        e = s + len(rows) - 1
        self.beginInsertRows(QModelIndex(), s, e)
        self._rows.extend(rows)
        self.endInsertRows()

    def clear(self):
        self.set_data([], [])

    def rowCount(self, parent=QModelIndex()):
        return len(self._rows)

    def columnCount(self, parent=QModelIndex()):
        return len(self._cols)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal and 0 <= section < len(self._cols):
            return self._cols[section]
        return str(section + 1)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        if role == Qt.DisplayRole:
            try:
                return self._rows[index.row()][index.column()]
            except Exception:
                return ""
        return None


class _TableTab(QWidget):
    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self._stack = QStackedLayout()
        root.addLayout(self._stack, 1)

        self._empty = QLabel("暂无执行操作")
        self._empty.setAlignment(Qt.AlignCenter)
        self._empty.setProperty("muted", True)

        self.view = QTableView()
        self.view.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.model = LogTableModel()
        self.view.setModel(self.model)

        self._stack.addWidget(self._empty)
        self._stack.addWidget(self.view)
        self._stack.setCurrentWidget(self._empty)

        # NOTE: resizeColumnsToContents can be expensive on huge previews.
        self._fit_timer = QTimer(self)
        self._fit_timer.setSingleShot(True)
        self._fit_timer.timeout.connect(self._safe_fit)

    def _safe_fit(self):
        try:
            if self.model.rowCount() <= 1200:
                self.view.resizeColumnsToContents()
        except Exception:
            pass

    def set_cols(self, cols: List[str]):
        self.model.set_data(cols, [])
        # stay empty until we have rows
        self._stack.setCurrentWidget(self._empty)
        self._fit_timer.start(150)

    def append_rows(self, rows: List[Tuple[str, ...]]):
        self.model.append_rows(rows)
        if self.model.rowCount() > 0:
            self._stack.setCurrentWidget(self.view)
        if self.model.rowCount() <= 200:
            self._fit_timer.start(150)

    def clear(self):
        self.model.clear()
        self._stack.setCurrentWidget(self._empty)



class _CurveTab(QWidget):
    """Interactive charging curves with flat UI.

    What you get:
      - Voltage(V) vs Current(A) in ONE chart with dual y-axes (left V, right A)
      - Temperature(°C) vs Power(W=V*I) in ONE chart with dual y-axes (left °C, right W)
      - Interactive: wheel zoom, rectangle zoom, hover tooltip, reset zoom
      - Unit conversion: mV->V, uA/mA->A
      - Downsample to keep UI responsive on 2-4GB log packs
    """

    MAX_POINTS = 5000

    class _InteractiveChartView(QChartView):
        def __init__(self, chart: QChart):
            super().__init__(chart)
            # PySide6: QChartView.setRenderHint expects QPainter.RenderHint
            self.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            # User requirement: no wheel zoom / rubber-band zoom for axis adjustment.
            self.setRubberBand(QChartView.NoRubberBand)
            # callback: fn(x_value: float)
            self.on_move = None

        def wheelEvent(self, event):
            # Disable zooming via wheel.
            event.ignore()

        def mouseMoveEvent(self, event):
            try:
                if callable(self.on_move):
                    val = self.chart().mapToValue(event.position().toPoint())
                    self.on_move(float(val.x()))
            except Exception:
                pass
            super().mouseMoveEvent(event)

    @staticmethod
    def _pick_col(cols: List[str], candidates: List[str]) -> str:
        low = {c.lower(): c for c in cols}
        for k in candidates:
            if k.lower() in low:
                return low[k.lower()]
        for c in cols:
            cl = c.lower()
            for k in candidates:
                if cl.startswith(k.lower()):
                    return c
        return ""

    @staticmethod
    def _to_float(x: str) -> float:
        try:
            return float(str(x).strip())
        except Exception:
            return float("nan")

    @staticmethod
    def _as_volts(v: float) -> float:
        if v != v:
            return v
        return v / 1000.0 if abs(v) >= 1000 else v

    @staticmethod
    def _as_amps(i: float) -> float:
        if i != i:
            return i
        a = abs(i)
        if a >= 10000:
            return i / 1_000_000.0  # uA
        if a >= 100:
            return i / 1000.0  # mA
        return i

    def __init__(self):
        super().__init__()

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(UI.GAP)

        self._stack = QStackedLayout()
        root.addLayout(self._stack, 1)

        self._empty = QLabel("暂无执行操作")
        self._empty.setAlignment(Qt.AlignCenter)
        self._empty.setProperty("muted", True)
        self._stack.addWidget(self._empty)

        self._content = QWidget()
        lay = QVBoxLayout(self._content)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(UI.GAP)

        bar = QHBoxLayout()
        bar.setContentsMargins(0, 0, 0, 0)
        bar.setSpacing(UI.GAP)
        # Zooming is disabled by design (user requirement). Keep the button hidden
        # to avoid confusing UX, while keeping the handler for compatibility.
        self.btn_reset_zoom = QPushButton("重置缩放")
        self.btn_reset_zoom.setProperty("secondary", True)
        self.btn_reset_zoom.setVisible(False)
        bar.addWidget(self.btn_reset_zoom)

        # series toggles (global; applied to both Healthd/Vbat)
        self.cb_v = QCheckBox("V")
        self.cb_i = QCheckBox("I")
        self.cb_t = QCheckBox("T")
        self.cb_p = QCheckBox("P")
        for cb in (self.cb_v, self.cb_i, self.cb_t, self.cb_p):
            cb.setChecked(True)
            bar.addWidget(cb)
        bar.addStretch(1)
        lay.addLayout(bar)

        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)

        # NOTE: When tick interval is small (dense x labels), stacking 2 charts vertically
        # can clip titles/labels in a single page. Use a 2-page toggle per dataset.
        self.health_v_i_view = self._make_dual_axis_chart("Healthd 电压/电流  (V/I)", "电压(V)", "电流(A)")
        self.health_t_p_view = self._make_dual_axis_chart("Healthd 温度/功率  (T/P)", "温度(°C)", "功率(W)")
        self.tabs.addTab(self._make_two_page_dataset(self.health_v_i_view, self.health_t_p_view), "Healthd")

        self.vbat_v_i_view = self._make_dual_axis_chart("Vbat 电压/电流  (V/I)", "电压(V)", "电流(A)")
        self.vbat_t_p_view = self._make_dual_axis_chart("Vbat 温度/功率  (T/P)", "温度(°C)", "功率(W)")
        self.tabs.addTab(self._make_two_page_dataset(self.vbat_v_i_view, self.vbat_t_p_view), "Vbat")

        self._stack.addWidget(self._content)
        self._stack.setCurrentWidget(self._empty)

        self._health_store = ""
        self._vbat_store = ""
        self._health_cols: List[str] = []
        self._vbat_cols: List[str] = []

        self.btn_reset_zoom.clicked.connect(self._reset_zoom_all)
        for cb in (self.cb_v, self.cb_i, self.cb_t, self.cb_p):
            cb.stateChanged.connect(self._apply_visibility)

        # Cached data for hover linkage
        self._health_data: Dict[str, List[float]] = {}
        self._vbat_data: Dict[str, List[float]] = {}

        # Link hover across paired charts
        self.health_v_i_view.on_move = lambda xv: self._on_hover(dataset="health", x_value=xv)
        self.health_t_p_view.on_move = lambda xv: self._on_hover(dataset="health", x_value=xv)
        self.vbat_v_i_view.on_move = lambda xv: self._on_hover(dataset="vbat", x_value=xv)
        self.vbat_t_p_view.on_move = lambda xv: self._on_hover(dataset="vbat", x_value=xv)

    def _make_two_page_dataset(self, view_vi: QChartView, view_tp: QChartView) -> QWidget:
        """Create a dataset page with 2 sub-pages (V/I and T/P).

        This avoids vertical compression and label clipping when the UI height is limited.
        """
        w = QWidget()
        root = QVBoxLayout(w)
        # Compact layout: keep the page switcher close to the dataset tabs.
        # Too much vertical spacing makes the chart look "floating" and wastes space.
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(6)

        bar = QHBoxLayout()
        # Tighten V/I & T/P switcher row.
        bar.setContentsMargins(0, 0, 0, 2)
        bar.setSpacing(8)

        btn_vi = QPushButton("V/I")
        btn_tp = QPushButton("T/P")
        for b in (btn_vi, btn_tp):
            b.setCheckable(True)
            # Use toggle styling (checked = active) to improve affordance.
            b.setProperty("role", "toggle")
            b.setMinimumWidth(64)
            b.setFixedHeight(28)
        btn_vi.setChecked(True)
        bar.addWidget(btn_vi)
        bar.addWidget(btn_tp)
        bar.addStretch(1)
        root.addLayout(bar)

        stack = QStackedWidget()
        stack.addWidget(view_vi)
        stack.addWidget(view_tp)
        root.addWidget(stack, 1)

        def _go(idx: int):
            stack.setCurrentIndex(idx)
            btn_vi.setChecked(idx == 0)
            btn_tp.setChecked(idx == 1)

        btn_vi.clicked.connect(lambda: _go(0))
        btn_tp.clicked.connect(lambda: _go(1))
        return w

    def _make_dual_axis_chart(self, title: str, y_left: str, y_right: str) -> QChartView:
        chart = QChart()
        chart.setTitle(title)
        # Legend consumes precious vertical space on dense time-series; show series keys in title.
        chart.legend().setVisible(False)
        chart.setBackgroundVisible(False)
        chart.setPlotAreaBackgroundVisible(False)
        # Keep enough breathing room for dense labels; prevents clipping.
        try:
            # Give extra bottom space so x labels won't be clipped/hidden.
            chart.setMargins(QMargins(10, 8, 10, 28))
        except Exception:
            pass

        # X axis uses android_time labels (categorical labels on numeric id positions)
        ax_x = QCategoryAxis()
        # Avoid occupying vertical space with a title; the chart title already conveys meaning.
        try:
            # Some QtCharts builds still paint the title even when empty; hide aggressively.
            ax_x.setTitleText("")
            if hasattr(ax_x, "setTitleVisible"):
                ax_x.setTitleVisible(False)
            try:
                ax_x.setTitleBrush(QBrush(Qt.transparent))
            except Exception:
                pass
        except Exception:
            pass
        # Ensure x labels are actually rendered (Qt may hide when layout is tight)
        try:
            ax_x.setLabelsVisible(True)
            # Tilt to avoid overlap; keeps labels visible on narrow panels
            ax_x.setLabelsAngle(-45)
            ax_x.setLabelsPosition(QCategoryAxis.AxisLabelsPositionOnValue)
        except Exception:
            pass
        ax_l = QValueAxis(); ax_l.setTitleText(y_left)
        ax_r = QValueAxis(); ax_r.setTitleText(y_right)
        chart.addAxis(ax_x, Qt.AlignBottom)
        chart.addAxis(ax_l, Qt.AlignLeft)
        chart.addAxis(ax_r, Qt.AlignRight)

        # Subtle grid: improves readability without introducing heavy "square paper" look.
        try:
            ax_x.setGridLineVisible(False)
            ax_x.setMinorGridLineVisible(False)
        except Exception:
            pass
        for ax in (ax_l, ax_r):
            try:
                ax.setGridLineVisible(True)
                ax.setMinorGridLineVisible(False)
                # Light grid color
                if hasattr(ax, "setGridLineColor"):
                    ax.setGridLineColor(QColor("#ECEFF1"))
            except Exception:
                pass

        view = self._InteractiveChartView(chart)
        # With per-dataset paging, one chart occupies the panel; give it more height.
        view.setMinimumHeight(420)
        view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        return view

    # ------------------- time label formatting -------------------
    @staticmethod
    def _format_android_time_label(raw: str) -> str:
        """Normalize android_time label to HH:MM:SS."""
        s = (raw or "").strip()
        if not s:
            return ""
        # If a full datetime is provided, keep only time part
        if " " in s:
            s = s.split(" ")[-1]
        # Drop timezone suffixes if any
        if "+" in s and ":" in s:
            s = s.split("+")[0]
        if s.endswith("Z") and ":" in s:
            s = s[:-1]
        # Drop fractional seconds
        if "." in s:
            s = s.split(".")[0]
        parts = s.split(":")
        if len(parts) >= 3:
            hh, mm, ss = parts[0], parts[1], parts[2]
            try:
                return f"{int(hh):02d}:{int(mm):02d}:{int(ss):02d}"
            except Exception:
                return f"{hh}:{mm}:{ss}"[-8:]
        if len(parts) == 2:
            hh, mm = parts
            try:
                return f"{int(hh):02d}:{int(mm):02d}:00"
            except Exception:
                return f"{hh}:{mm}:00"[-8:]
        return s[-8:]

    @staticmethod
    def _nice_interval(span: float, target_ticks: int = 10) -> float:
        """Return a 'nice' tick interval (1/2/5 * 10^k)."""
        if span <= 0 or span != span:
            return 1.0
        raw = span / max(2, target_ticks)
        import math
        p = 10 ** math.floor(math.log10(raw))
        m = raw / p
        if m <= 1:
            n = 1
        elif m <= 2:
            n = 2
        elif m <= 5:
            n = 5
        else:
            n = 10
        return float(n * p)

    @staticmethod
    def _set_fixed_axis(axis: QValueAxis, lo: float, hi: float, interval: float, fmt: str = "%.2f"):
        # QValueAxis supports fixed ticks in Qt6; keep compatibility with older bindings.
        axis.setLabelFormat(fmt)
        axis.setRange(float(lo), float(hi))
        # Prefer fixed 10-division ticks for predictability.
        # Some QtCharts bindings expose setTickInterval but silently ignore it;
        # enforce tickCount as the ultimate fallback.
        ok_interval = False
        if hasattr(axis, "setTickType") and hasattr(axis, "setTickInterval"):
            try:
                axis.setTickType(QValueAxis.TickType.TicksFixed)  # type: ignore[attr-defined]
                axis.setTickInterval(float(interval))
                ok_interval = True
            except Exception:
                ok_interval = False
        try:
            # 10 equal divisions => 11 tick marks
            axis.setTickCount(11)
        except Exception:
            pass
        if not ok_interval:
            # Best-effort: align tickCount to interval-derived tick number
            try:
                ticks = int(round((hi - lo) / max(interval, 1e-9))) + 1
                axis.setTickCount(max(2, min(60, ticks)))
            except Exception:
                pass

    # ------------------- best-practice axis policy -------------------
    @staticmethod
    def _quantile(vv: List[float], q: float) -> float:
        """Simple quantile without numpy; vv must be non-empty and finite-filtered."""
        if not vv:
            return float('nan')
        q = max(0.0, min(1.0, float(q)))
        n = len(vv)
        if n == 1:
            return float(vv[0])
        pos = q * (n - 1)
        lo = int(pos)
        hi = min(n - 1, lo + 1)
        frac = pos - lo
        return float(vv[lo] * (1.0 - frac) + vv[hi] * frac)

    @classmethod
    def _robust_minmax(cls, data: List[float], *, q_lo: float = 0.01, q_hi: float = 0.99) -> Tuple[float, float]:
        vv = sorted([v for v in data if v == v])
        if not vv:
            return 0.0, 1.0
        lo = cls._quantile(vv, q_lo)
        hi = cls._quantile(vv, q_hi)
        if lo == hi:
            lo -= 1.0
            hi += 1.0
        if hi < lo:
            lo, hi = hi, lo
        return float(lo), float(hi)

    @staticmethod
    def _snap_step(span: float, preferred: List[float], target_ticks: int = 7) -> float:
        """Pick a human-friendly tick step; keep major ticks ~6-8 when possible."""
        span = abs(float(span))
        if span <= 0 or span != span:
            return preferred[0] if preferred else 1.0
        # Try preferred directly
        for s in preferred:
            if s <= 0:
                continue
            if span / s <= max(4, target_ticks + 1):
                return float(s)
        # Fallback: nice 1/2/5
        return _CurveTab._nice_interval(span, target_ticks=target_ticks)

    @staticmethod
    def _align_bounds(lo: float, hi: float, step: float) -> Tuple[float, float]:
        import math
        if step <= 0 or step != step:
            return float(lo), float(hi)
        lo2 = math.floor(lo / step) * step
        hi2 = math.ceil(hi / step) * step
        if lo2 == hi2:
            lo2 -= step
            hi2 += step
        return float(lo2), float(hi2)

    @staticmethod
    def _make_compact_category_axis(title: str, *, lo: float, hi: float, data: List[float], dense_hint: float, max_labels: int = 22) -> QCategoryAxis:
        """Non-uniform axis with optional '...' labels for sparse regions."""
        ax = QCategoryAxis()
        ax.setTitleText(title)
        ax.setRange(float(lo), float(hi))
        try:
            ax.setGridLineVisible(False)
        except Exception:
            pass

        vv = [v for v in data if v == v]
        if not vv:
            ax.append(str(lo), float(lo))
            ax.append(str(hi), float(hi))
            return ax

        vv.sort()
        # Dense core = [q10, q90]
        q10 = vv[int(0.10 * (len(vv) - 1))]
        q90 = vv[int(0.90 * (len(vv) - 1))]
        core_lo = max(lo, q10)
        core_hi = min(hi, q90)
        if core_hi < core_lo:
            core_lo, core_hi = lo, hi

        # Decide dense step (but keep label count bounded)
        span_core = max(1e-9, core_hi - core_lo)
        dense_step = float(dense_hint)
        est = int(span_core / max(dense_step, 1e-9)) + 1
        if est > max_labels:
            dense_step = _CurveTab._nice_interval(span_core, target_ticks=max_labels - 6)

        points: List[Tuple[float, str]] = []
        points.append((float(lo), f"{lo:g}"))
        if core_lo - lo > 4 * dense_step:
            points.append(((lo + core_lo) / 2.0, "..."))

        # Dense core labels
        v = core_lo
        while v <= core_hi + 1e-9:
            points.append((float(v), f"{v:g}"))
            v += dense_step

        if hi - core_hi > 4 * dense_step:
            points.append(((core_hi + hi) / 2.0, "..."))
        points.append((float(hi), f"{hi:g}"))

        # De-dup and keep sorted unique by value
        pts_sorted = []
        seen = set()
        for val, lab in sorted(points, key=lambda t: t[0]):
            key = round(val, 6)
            if key in seen:
                continue
            seen.add(key)
            pts_sorted.append((val, lab))

        for val, lab in pts_sorted:
            ax.append(lab, float(val))
        return ax

    def _reset_zoom_all(self):
        # Zoom is disabled (wheel/rubber-band). Keep as a no-op for compatibility.
        return

    def _apply_visibility(self):
        """Apply global V/I/T/P toggle to all charts (best-effort)."""
        want = {
            "V": self.cb_v.isChecked(),
            "Vbat": self.cb_v.isChecked(),
            "Vbus": self.cb_v.isChecked(),
            "I": self.cb_i.isChecked(),
            "T": self.cb_t.isChecked(),
            "P": self.cb_p.isChecked(),
        }
        for view in (self.health_v_i_view, self.health_t_p_view, self.vbat_v_i_view, self.vbat_t_p_view):
            try:
                series_map = getattr(view, "_series_by_name", {})
                for name, s in series_map.items():
                    if name.startswith("__"):
                        continue
                    s.setVisible(bool(want.get(name, True)))
            except Exception:
                pass

    @staticmethod
    def _nearest_index(xs: List[float], x_value: float) -> int:
        if not xs:
            return -1
        # xs is sorted by id; binary search
        import bisect
        i = bisect.bisect_left(xs, x_value)
        if i <= 0:
            return 0
        if i >= len(xs):
            return len(xs) - 1
        return i if abs(xs[i] - x_value) < abs(xs[i - 1] - x_value) else i - 1

    def _ensure_cursor(self, view: QChartView) -> QLineSeries:
        """Create (or reuse) a vertical cursor line series."""
        chart = view.chart()
        s = getattr(view, "_cursor_series", None)
        if isinstance(s, QLineSeries):
            return s
        s = QLineSeries()
        s.setName("__cursor")
        chart.addSeries(s)
        # attach to x + left axis
        axes_x = chart.axes(Qt.Horizontal)
        axes_y = chart.axes(Qt.Vertical)
        if axes_x and axes_y:
            try:
                s.attachAxis(axes_x[0])
            except Exception:
                pass
            try:
                s.attachAxis(axes_y[0])
            except Exception:
                pass
        setattr(view, "_cursor_series", s)
        # keep hidden by default
        s.setVisible(False)
        # put in map for visibility skip
        try:
            view._series_by_name["__cursor"] = s  # type: ignore[attr-defined]
        except Exception:
            pass
        return s

    def _update_cursor(self, view: QChartView, x_at: float):
        try:
            chart = view.chart()
            axes_x = chart.axes(Qt.Horizontal)
            axes_y = chart.axes(Qt.Vertical)
            if not axes_x or not axes_y:
                return
            ax_y = axes_y[0]
            # get y-range
            ylo = getattr(ax_y, "min", lambda: 0.0)()
            yhi = getattr(ax_y, "max", lambda: 1.0)()
            s = self._ensure_cursor(view)
            s.clear()
            s.append(QPointF(float(x_at), float(ylo)))
            s.append(QPointF(float(x_at), float(yhi)))
            s.setVisible(True)
        except Exception:
            pass

    def _on_hover(self, *, dataset: str, x_value: float):
        """Link hover across the paired charts and show a unified tooltip."""
        data = self._health_data if dataset == "health" else self._vbat_data
        xs = data.get("x", [])
        idx = self._nearest_index(xs, x_value)
        if idx < 0:
            return
        x_at = float(xs[idx])

        # Compose unified tooltip
        def g(k: str) -> float:
            arr = data.get(k, [])
            if 0 <= idx < len(arr):
                return float(arr[idx])
            return float("nan")

        v = g("v")
        i = g("i")
        temp = g("t")
        p = g("p")
        lvl = g("lvl")

        # Prefer human-readable android_time labels if available.
        tlabels = data.get("time", [])
        time_str = ""
        if 0 <= idx < len(tlabels):
            try:
                time_str = str(tlabels[idx])
            except Exception:
                time_str = ""
        if not time_str:
            # Fallback to sample index; x is usually a monotonic index.
            time_str = f"{x_at:.0f}"

        parts = [f"Time: {time_str}"]
        if v == v:
            parts.append(f"V: {v:.3g} V")
        if i == i:
            parts.append(f"I: {i:.3g} A")
        if temp == temp:
            parts.append(f"Temp: {temp:.3g} °C")
        if p == p:
            parts.append(f"P: {p:.3g} W")
        if lvl == lvl:
            parts.append(f"L: {lvl:.0f}%")
        tip = "\n".join(parts)

        if dataset == "health":
            self._update_cursor(self.health_v_i_view, x_at)
            self._update_cursor(self.health_t_p_view, x_at)
            self.health_v_i_view.setToolTip(tip)
            self.health_t_p_view.setToolTip(tip)
        else:
            self._update_cursor(self.vbat_v_i_view, x_at)
            self._update_cursor(self.vbat_t_p_view, x_at)
            self.vbat_v_i_view.setToolTip(tip)
            self.vbat_t_p_view.setToolTip(tip)

    def clear(self):
        self._health_store = ""
        self._vbat_store = ""
        self._health_cols = []
        self._vbat_cols = []
        for v in [self.health_v_i_view, self.health_t_p_view, self.vbat_v_i_view, self.vbat_t_p_view]:
            chart = v.chart()
            for s in list(chart.series()):
                chart.removeSeries(s)
        self._stack.setCurrentWidget(self._empty)

    def set_sources(self, *, health_store: str = "", health_cols: List[str] | None = None,
                    vbat_store: str = "", vbat_cols: List[str] | None = None):
        self._health_store = health_store or ""
        self._vbat_store = vbat_store or ""
        self._health_cols = list(health_cols or [])
        self._vbat_cols = list(vbat_cols or [])
        if self._health_store or self._vbat_store:
            self._stack.setCurrentWidget(self._content)
            self.render()
        else:
            self._stack.setCurrentWidget(self._empty)

    def _get_cols_from_store(self, store_path: str) -> List[str]:
        try:
            return SqliteLogStore.open_existing(Path(store_path)).columns
        except Exception:
            return []

    def _load_downsampled(self, store_path: str, want_cols: List[str], *, time_col: str = "") -> Tuple[List[float], Dict[str, List[float]], List[str]]:
        if not store_path or not Path(store_path).exists():
            return [], {c: [] for c in want_cols}, []

        store = SqliteLogStore.open_existing(Path(store_path))
        try:
            cols = store.columns
            idx = {c: i for i, c in enumerate(cols)}
            total = store.count()
            if total <= 0:
                return [], {c: [] for c in want_cols}, []
            step = max(1, total // self.MAX_POINTS)

            time_idx = idx.get(time_col) if time_col else None

            select_ids: List[str] = []
            out_cols: List[str] = []
            for c in want_cols:
                if not c:
                    continue
                i = idx.get(c)
                if i is None:
                    continue
                select_ids.append(f"c{i}")
                out_cols.append(c)
            if not select_ids:
                return [], {c: [] for c in want_cols}, []

            import sqlite3
            conn = sqlite3.connect(f"file:{Path(store_path).as_posix()}?mode=ro", uri=True, check_same_thread=False)
            try:
                # If android_time exists, fetch it too (as TEXT) for x-axis labeling.
                time_sel = f",c{int(time_idx)}" if time_idx is not None else ""
                sql = f"SELECT id{time_sel},{','.join(select_ids)} FROM rows WHERE (id % ?) = 0 OR id = ? ORDER BY id;"
                cur = conn.execute(sql, (int(step), int(total)))
                x: List[float] = []
                y: Dict[str, List[float]] = {c: [] for c in want_cols}
                tlabels: List[str] = []
                for row in cur.fetchall():
                    x.append(float(row[0]))
                    base = 1
                    if time_idx is not None:
                        try:
                            tlabels.append(str(row[1]))
                        except Exception:
                            tlabels.append("")
                        base = 2
                    for j, c in enumerate(out_cols):
                        y[c].append(self._to_float(row[base + j]))
                return x, y, tlabels
            finally:
                conn.close()
        finally:
            store.close()

    def _apply_series(self, view: QChartView, *, x: List[float], left: Dict[str, List[float]], right: Dict[str, List[float]]):
        chart = view.chart()
        for s in list(chart.series()):
            chart.removeSeries(s)

        axes_x = chart.axes(Qt.Horizontal)
        axes_y = chart.axes(Qt.Vertical)
        if not axes_x or len(axes_y) < 2:
            return
        ax_x = axes_x[0]
        ax_l = axes_y[0]  # type: ignore
        ax_r = axes_y[1]  # type: ignore

        # store series for visibility toggles
        view._series_by_name = {}  # type: ignore[attr-defined]

        def add(name: str, ys: List[float], axis):
            s = QLineSeries()
            s.setName(name)
            # Standard palette (fixed, readable):
            # V=blue, I=green, T=red, P=orange
            try:
                palette = {
                    "V": QColor("#1f77b4"),  # blue
                    "I": QColor("#2ca02c"),  # green
                    "T": QColor("#d62728"),  # red
                    "P": QColor("#ff7f0e"),  # orange
                }
                col = palette.get(name, QColor("#4c4c4c"))
                pen = QPen(col)
                pen.setWidthF(1.6)
                s.setPen(pen)
            except Exception:
                pass
            pts: List[QPointF] = []
            for xi, yi in zip(x, ys):
                if yi != yi:
                    continue
                pts.append(QPointF(float(xi), float(yi)))
            if pts:
                s.append(pts)
            chart.addSeries(s)
            s.attachAxis(ax_x)
            s.attachAxis(axis)

            try:
                view._series_by_name[name] = s  # type: ignore[attr-defined]
            except Exception:
                pass

        for n, ys in left.items():
            add(n, ys, ax_l)
        for n, ys in right.items():
            add(n, ys, ax_r)

        # ---------------- Axis configuration (user-specified) ----------------
        # X-axis: use android_time labels if available; otherwise keep numeric id.
        if x:
            xlo, xhi = float(min(x)), float(max(x))
            try:
                ax_x.setRange(xlo, xhi)
            except Exception:
                pass
            # Equal partitions: 10 intervals => 11 tick labels
            tlabels = getattr(view, "_time_labels", [])
            if isinstance(ax_x, QCategoryAxis) and tlabels:
                try:
                    ax_x.clear()
                    # Critical: align category axis start value to the first x.
                    # Otherwise Qt may allocate an implicit [0..x0] category and
                    # hide labels or leave a blank region at the left.
                    try:
                        ax_x.setStartValue(xlo)
                    except Exception:
                        pass
                    n = len(x)
                    for k in range(11):
                        idx = int(round(k * (n - 1) / 10.0)) if n > 1 else 0
                        idx = max(0, min(n - 1, idx))
                        raw_lab = str(tlabels[idx]) if idx < len(tlabels) else ""
                        lab = self._format_android_time_label(raw_lab)
                        if not lab:
                            lab = str(idx)
                        ax_x.append(lab, float(x[idx]))
                    # Re-apply range after clear/append (some bindings reset it)
                    try:
                        ax_x.setRange(xlo, xhi)
                        ax_x.setLabelsVisible(True)
                    except Exception:
                        pass
                except Exception:
                    pass
            elif isinstance(ax_x, QValueAxis):
                try:
                    ax_x.setLabelFormat("%.0f")
                    ax_x.setTickCount(11)
                except Exception:
                    pass

        title = (chart.title() or "").lower()
        left_data = [v for ys in left.values() for v in ys]
        right_data = [v for ys in right.values() for v in ys]

        def set_axis(axis, data: List[float], *, kind: str, fmt: str):
            # User requirement: range = [min-pad, max+pad], then equal split into 10 parts.
            vv = [v for v in data if v == v]
            if not vv:
                try:
                    axis.setRange(0, 1)
                except Exception:
                    pass
                return
            lo = float(min(vv))
            hi = float(max(vv))
            if lo == hi:
                lo -= 1.0
                hi += 1.0
            pad = 0.0
            if kind == "v":
                pad = 0.2
            elif kind == "i":
                pad = 0.8
            elif kind == "t":
                pad = 1.0
            else:
                pad = 2.0
            lo2 = lo - pad
            hi2 = hi + pad
            interval = (hi2 - lo2) / 10.0
            try:
                if isinstance(axis, QValueAxis):
                    axis.setLabelFormat(fmt)
                    axis.setRange(float(lo2), float(hi2))
                    if hasattr(axis, "setTickType") and hasattr(axis, "setTickInterval"):
                        axis.setTickType(QValueAxis.TickType.TicksFixed)  # type: ignore[attr-defined]
                        axis.setTickInterval(float(interval))
                    # Always enforce 10 divisions (11 ticks); some bindings ignore tickInterval.
                    axis.setTickCount(11)
                else:
                    axis.setRange(float(lo2), float(hi2))
            except Exception:
                pass

        if "电压" in title and "电流" in title:
            if isinstance(ax_l, QValueAxis):
                set_axis(ax_l, left_data, kind="v", fmt="%.2f" if (max([v for v in left_data if v==v], default=0)-min([v for v in left_data if v==v], default=0))<1 else "%.1f")
            if isinstance(ax_r, QValueAxis):
                set_axis(ax_r, right_data, kind="i", fmt="%.1f")
        elif "温度" in title and "功率" in title:
            # Keep compact category axis optional, but default to robust value axes for readability.
            if isinstance(ax_l, QValueAxis):
                set_axis(ax_l, left_data, kind="t", fmt="%.1f")
            if isinstance(ax_r, QValueAxis):
                set_axis(ax_r, right_data, kind="p", fmt="%.1f")
        else:
            if isinstance(ax_l, QValueAxis):
                set_axis(ax_l, left_data, kind="v", fmt="%.2f")
            if isinstance(ax_r, QValueAxis):
                set_axis(ax_r, right_data, kind="i", fmt="%.2f")

    def render(self):
        # Healthd
        if self._health_store:
            cols = self._health_cols or self._get_cols_from_store(self._health_store)
            timecol = self._pick_col(cols, ["android_time", "androd_time", "time", "datetime", "timestamp"])
            vcol = self._pick_col(cols, ["v", "voltage", "vbatt", "vbat", "v_bat"])
            ccol = self._pick_col(cols, ["c", "current", "ibat", "i", "curr"])
            tcol = self._pick_col(cols, ["t", "temp", "temperature"])
            lcol = self._pick_col(cols, ["l", "level", "soc", "battery_level"]) 

            x, y, tl = self._load_downsampled(self._health_store, [vcol, ccol, tcol, lcol], time_col=timecol)
            vv = [self._as_volts(v) for v in y.get(vcol, [])]
            ii = [self._as_amps(i) for i in y.get(ccol, [])]
            tt = [t for t in y.get(tcol, [])]
            ll = [l for l in y.get(lcol, [])]
            pp = [v * i if (v == v and i == i) else float('nan') for v, i in zip(vv, ii)]

            setattr(self.health_v_i_view, "_time_labels", list(tl))
            setattr(self.health_t_p_view, "_time_labels", list(tl))

            self._apply_series(self.health_v_i_view, x=x, left={"V": vv} if vv else {}, right={"I": ii} if ii else {})
            self._apply_series(self.health_t_p_view, x=x, left={"T": tt} if tt else {}, right={"P": pp} if pp else {})

            # Keep aligned human-readable time labels for tooltips.
            self._health_data = {"x": list(x), "time": list(tl), "v": list(vv), "i": list(ii), "t": list(tt), "p": list(pp), "lvl": list(ll)}
            self._apply_visibility()
        else:
            self._apply_series(self.health_v_i_view, x=[], left={}, right={})
            self._apply_series(self.health_t_p_view, x=[], left={}, right={})
            self._health_data = {}

        # Vbat
        if self._vbat_store:
            cols = self._vbat_cols or self._get_cols_from_store(self._vbat_store)
            timecol = self._pick_col(cols, ["android_time", "androd_time", "time", "datetime", "timestamp"])
            vbat = self._pick_col(cols, ["vbat", "vbatt", "v_bat", "voltage"])
            vbus = self._pick_col(cols, ["vbus"])
            icol = self._pick_col(cols, ["i", "ibus", "ibat", "current"])
            tcol = self._pick_col(cols, ["t", "T", "temp", "temperature"])
            lcol = self._pick_col(cols, ["l", "level", "soc", "battery_level"])

            x, y, tl = self._load_downsampled(self._vbat_store, [vbat, vbus, icol, tcol, lcol], time_col=timecol)
            vb = [self._as_volts(v) for v in y.get(vbat, [])]
            vbu = [self._as_volts(v) for v in y.get(vbus, [])]
            ii = [self._as_amps(i) for i in y.get(icol, [])]
            tt = [t for t in y.get(tcol, [])]
            ll = [l for l in y.get(lcol, [])]
            pp = [v * i if (v == v and i == i) else float('nan') for v, i in zip(vb, ii)]

            setattr(self.vbat_v_i_view, "_time_labels", list(tl))
            setattr(self.vbat_t_p_view, "_time_labels", list(tl))

            left_vi: Dict[str, List[float]] = {}
            if vb:
                left_vi["Vbat"] = vb
            if vbu:
                left_vi["Vbus"] = vbu
            self._apply_series(self.vbat_v_i_view, x=x, left=left_vi, right={"I": ii} if ii else {})
            self._apply_series(self.vbat_t_p_view, x=x, left={"T": tt} if tt else {}, right={"P": pp} if pp else {})

            # store primary voltage as v (prefer Vbat), keep vbus for completeness
            # Keep aligned human-readable time labels for tooltips.
            self._vbat_data = {"x": list(x), "time": list(tl), "v": list(vb), "i": list(ii), "t": list(tt), "p": list(pp), "lvl": list(ll), "vbus": list(vbu)}
            self._apply_visibility()
        else:
            self._apply_series(self.vbat_v_i_view, x=[], left={}, right={})
            self._apply_series(self.vbat_t_p_view, x=[], left={}, right={})
            self._vbat_data = {}
class _EmptyableTable(QWidget):
    """A table with an empty placeholder shown when there is no data."""

    def __init__(self, headers: List[str]):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self._stack = QStackedLayout()
        root.addLayout(self._stack, 1)

        self._empty = QLabel("暂无执行操作")
        self._empty.setAlignment(Qt.AlignCenter)
        self._empty.setProperty("muted", True)

        self.table = QTableWidget(0, len(headers))
        self.table.setHorizontalHeaderLabels(headers)

        self._stack.addWidget(self._empty)
        self._stack.addWidget(self.table)
        self._stack.setCurrentWidget(self._empty)

    def clear(self):
        self.table.setRowCount(0)
        self._stack.setCurrentWidget(self._empty)

    def set_has_data(self, has_data: bool):
        self._stack.setCurrentWidget(self.table if has_data else self._empty)


class LogResults(QWidget):
    """Right side results for log analysis + AI protocol analysis.

    Tabs:
      - Healthd 数据
      - Vbat 数据
      - AI 协议：结论概览 / Session / 协议轨迹 / 证据 / 报告 / 运行日志
    """

    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(UI.GAP)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)

        # --- data tabs ---
        self.tab_healthd = _TableTab()
        self.tab_vbat = _TableTab()
        self.tab_curve = _CurveTab()
        self.tabs.addTab(self.tab_healthd, "Healthd数据")
        self.tabs.addTab(self.tab_vbat, "Vbat数据")
        self.tabs.addTab(self.tab_curve, "充电曲线")

        # --- AI protocol tabs (same structure as old AiResults) ---
        # Keep style consistent across tabs by using the same "empty placeholder -> content"
        # stacked pattern as other pages.
        self.ai_summary_view = QPlainTextEdit()
        self.ai_summary_view.setReadOnly(True)
        self.ai_summary_view.setFrameShape(QPlainTextEdit.NoFrame)

        self.ai_summary_empty = QLabel("暂无执行操作")
        self.ai_summary_empty.setAlignment(Qt.AlignCenter)
        self.ai_summary_empty.setProperty("muted", True)

        self.ai_summary_stack = QStackedLayout()
        w1 = QWidget(); l1 = QVBoxLayout(w1); l1.setContentsMargins(0,0,0,0); l1.setSpacing(0)
        l1.addLayout(self.ai_summary_stack, 1)
        self.ai_summary_stack.addWidget(self.ai_summary_empty)
        self.ai_summary_stack.addWidget(self.ai_summary_view)
        self.ai_summary_stack.setCurrentWidget(self.ai_summary_empty)

        self.ai_sessions_wrap = _EmptyableTable(["Group", "ID", "t_in", "t_out", "Protocol", "Health", "Phenomenon", "End/Reason"])
        self.ai_sessions = self.ai_sessions_wrap.table
        w2 = self.ai_sessions_wrap

        self.ai_timeline_wrap = _EmptyableTable(["协议", "轨迹/结论", "结果"])
        self.ai_timeline = self.ai_timeline_wrap.table
        w3 = self.ai_timeline_wrap

        self.ai_evidence_wrap = _EmptyableTable(["类别", "证据", "备注"])
        self.ai_evidence = self.ai_evidence_wrap.table
        w4 = self.ai_evidence_wrap

        self.ai_report = QPlainTextEdit()
        self.ai_report.setReadOnly(True)
        self.ai_report_empty = QLabel("暂无执行操作")
        self.ai_report_empty.setAlignment(Qt.AlignCenter)
        self.ai_report_empty.setProperty("muted", True)
        self.ai_report_stack = QStackedLayout()
        w5 = QWidget(); l5 = QVBoxLayout(w5); l5.setContentsMargins(0,0,0,0); l5.setSpacing(0)
        l5.addLayout(self.ai_report_stack, 1)
        self.ai_report_stack.addWidget(self.ai_report_empty)
        self.ai_report_stack.addWidget(self.ai_report)
        self.ai_report_stack.setCurrentWidget(self.ai_report_empty)

        # --- run log tab (empty/data stacked) ---
        self.runlog_view = QPlainTextEdit()
        self.runlog_view.setReadOnly(True)
        self.runlog_view.setFrameShape(QPlainTextEdit.NoFrame)

        self.runlog_empty = QLabel("暂无执行操作")
        self.runlog_empty.setAlignment(Qt.AlignCenter)
        self.runlog_empty.setProperty("muted", True)

        self.runlog_stack = QStackedLayout()
        w_run = QWidget()
        l_run = QVBoxLayout(w_run)
        l_run.setContentsMargins(0, 0, 0, 0)
        l_run.setSpacing(0)
        l_run.addLayout(self.runlog_stack, 1)
        self.runlog_stack.addWidget(self.runlog_empty)
        self.runlog_stack.addWidget(self.runlog_view)
        self.runlog_stack.setCurrentWidget(self.runlog_empty)

        # add AI tabs
        self.tabs.addTab(w1, "结论概览")
        self.tabs.addTab(w2, "Session")
        self.tabs.addTab(w3, "协议轨迹")
        self.tabs.addTab(w4, "证据")
        self.tabs.addTab(w5, "报告")
        self.tabs.addTab(w_run, "运行日志")

        # map parser name => tab
        self._parser_tabs: Dict[str, _TableTab] = {
            "Healthd": self.tab_healthd,
            "Vbat": self.tab_vbat,
            "HealthdParser": self.tab_healthd,
            "VbatParser": self.tab_vbat,
        }

    
    # ------------------- curves -------------------
    def set_curve_sources(self, res_map: dict):
        """Bind sqlite stores to curve tab and render curves."""
        try:
            h = res_map.get("HealthdParser") or res_map.get("Healthd")
            v = res_map.get("VbatParser") or res_map.get("Vbat")
            h_store = getattr(h, "store_path", "") if h else ""
            v_store = getattr(v, "store_path", "") if v else ""
            h_cols = getattr(h, "columns", []) if h else []
            v_cols = getattr(v, "columns", []) if v else []
            if hasattr(self, "tab_curve"):
                self.tab_curve.set_sources(health_store=h_store, health_cols=list(h_cols),
                                           vbat_store=v_store, vbat_cols=list(v_cols))
        except Exception:
            pass

# ------------------- run log -------------------
    def append_log(self, msg: str):
        """Append a log line to the run log tab.

        The tab uses an empty placeholder; the first log line switches the UI
        from the empty placeholder to the text view.
        """
        if self.runlog_stack.currentWidget() is self.runlog_empty:
            self.runlog_view.setPlainText("")
            self.runlog_stack.setCurrentWidget(self.runlog_view)
        self.runlog_view.appendPlainText(msg.rstrip("\n"))

    def clear_runlog(self):
        self.runlog_view.setPlainText("")
        self.runlog_stack.setCurrentWidget(self.runlog_empty)

    # ------------------- data tables -------------------
    def clear_tables(self):
        self.tab_healthd.clear()
        self.tab_vbat.clear()
        if hasattr(self, 'tab_curve'):
            self.tab_curve.clear()

    def set_cols(self, parser_name: str, cols: List[str]):
        tab = self._parser_tabs.get(parser_name)
        if tab is None:
            # best-effort routing
            if "health" in parser_name.lower():
                tab = self.tab_healthd
            elif "vbat" in parser_name.lower():
                tab = self.tab_vbat
        if tab:
            tab.set_cols(cols)

    def append_rows(self, parser_name: str, rows: List[Tuple[str, ...]]):
        tab = self._parser_tabs.get(parser_name)
        if tab is None:
            if "health" in parser_name.lower():
                tab = self.tab_healthd
            elif "vbat" in parser_name.lower():
                tab = self.tab_vbat
        if tab:
            tab.append_rows(rows)

    # ------------------- AI -------------------
    def clear_ai(self):
        self.ai_summary_view.setPlainText("")
        self.ai_summary_stack.setCurrentWidget(self.ai_summary_empty)
        self.ai_sessions_wrap.clear()
        self.ai_timeline_wrap.clear()
        self.ai_evidence_wrap.clear()
        self.ai_report.setPlainText("")
        self.ai_report_stack.setCurrentWidget(self.ai_report_empty)

    def set_ai_payload(self, data: dict):
        s = data.get("summary", {}) if isinstance(data, dict) else {}
        lines = [
            f"Session 数量: {s.get('session_cnt', '-')}",
            f"现象分类: {s.get('phenomenon', '-')}",
            f"子原因: {s.get('sub_reason', '-')}",
            f"PD 支持: {s.get('pd_supported', '-')}",
            f"TC30 支持: {s.get('tc30_supported', '-')}",
            f"HVDCP 运行: {s.get('hvdcp_running', '-')}",
        ]
        txt = "\n".join(lines)
        self.ai_summary_view.setPlainText(txt)
        self.ai_summary_stack.setCurrentWidget(self.ai_summary_view if txt.strip() else self.ai_summary_empty)
        self._fill_sessions(data.get("sessions", []))
        self._fill_3col(self.ai_timeline, data.get("protocol_timeline", []))
        self._fill_3col(self.ai_evidence, data.get("evidence", []))
        self.ai_sessions_wrap.set_has_data(self.ai_sessions.rowCount() > 0)
        self.ai_timeline_wrap.set_has_data(self.ai_timeline.rowCount() > 0)
        self.ai_evidence_wrap.set_has_data(self.ai_evidence.rowCount() > 0)
        rt = data.get("report_text", "")
        self.ai_report.setPlainText(rt)
        self.ai_report_stack.setCurrentWidget(self.ai_report if rt.strip() else self.ai_report_empty)

    def _fill_sessions(self, rows: List[dict]):
        self.ai_sessions.setRowCount(0)
        for row in rows:
            r = self.ai_sessions.rowCount()
            self.ai_sessions.insertRow(r)
            vals = [
                row.get("group", ""),
                row.get("id", ""),
                row.get("t_in", ""),
                row.get("t_out", ""),
                row.get("protocol", ""),
                row.get("health", ""),
                row.get("phenomenon", ""),
                row.get("end_reason", ""),
            ]
            for c, v in enumerate(vals):
                self.ai_sessions.setItem(r, c, QTableWidgetItem(str(v)))
        self.ai_sessions_wrap.set_has_data(self.ai_sessions.rowCount() > 0)

    @staticmethod
    def _fill_3col(tw: QTableWidget, rows):
        tw.setRowCount(0)
        if not rows:
            return
        for it in rows:
            # Accept both tuple/list payloads (a,b,c) and dict payloads.
            if isinstance(it, dict):
                a = it.get("c1", "")
                b = it.get("c2", "")
                cval = it.get("c3", "")
                # additional tolerated keys
                if not a and any(k in it for k in ("protocol", "cat", "type")):
                    a = it.get("protocol") or it.get("cat") or it.get("type") or ""
                if not b and any(k in it for k in ("trace", "evidence", "msg")):
                    b = it.get("trace") or it.get("evidence") or it.get("msg") or ""
                if not cval and any(k in it for k in ("result", "hint")):
                    cval = it.get("result") or it.get("hint") or ""
            else:
                try:
                    a, b, cval = it
                except Exception:
                    a, b, cval = str(it), "", ""

            r = tw.rowCount()
            tw.insertRow(r)
            tw.setItem(r, 0, QTableWidgetItem(str(a)))
            tw.setItem(r, 1, QTableWidgetItem(str(b)))
            tw.setItem(r, 2, QTableWidgetItem(str(cval)))

    def clear_all(self):
        self.clear_tables()
        self.clear_ai()
        self.clear_runlog()
