import csv
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple, Optional
from PySide6.QtCore import QThread, Signal
from ChargeAutoTool.core.adb import adb_cmd
from ChargeAutoTool.utils.helpers import run_cmd
from ChargeAutoTool.modules.log_analysis.analyzer import LogAnalyzer
from ChargeAutoTool.infrastructure.log_store_sqlite import SqliteLogStore


@dataclass
class CancelFlag:
    cancelled: bool = False

class AnalysisWorker(QThread):
    log_signal = Signal(str); init_cols_signal = Signal(object); batch_rows_signal = Signal(object); result_signal = Signal(object); finished_signal = Signal()
    def __init__(self, analyzer: LogAnalyzer, path, parser, *, store_dir: Path):
        super().__init__(); self.analyzer=analyzer; self.path=path; self.parser=parser
        self.store_dir = Path(store_dir)
        self.cancel_flag = CancelFlag(False)

    def cancel(self):
        self.cancel_flag.cancelled = True
    def run(self):
        try:
            self.analyzer.log_message = self.log_signal.emit
            res = self.analyzer.analyze_stream(
                self.path,
                self.parser,
                store_dir=self.store_dir,
                on_init_cols=self.init_cols_signal.emit,
                on_batch=self.batch_rows_signal.emit,
                cancel_flag=self.cancel_flag,
            )
            self.result_signal.emit(res)
        except Exception as e: self.log_signal.emit(f"[ERROR] 分析失败：{e}\n{traceback.format_exc()}\n")
        finally: self.finished_signal.emit()


class MultiAnalysisWorker(QThread):
    """Analyze one input path with multiple parsers sequentially.

    Signals payloads contain (parser_name, data) so UI can route to the right tab.
    """
    log_signal = Signal(str)
    init_cols_signal = Signal(object)   # (parser_name, cols)
    batch_rows_signal = Signal(object)  # (parser_name, rows)
    result_signal = Signal(object)      # dict[str, ParseResult]
    finished_signal = Signal()

    def __init__(self, analyzer: LogAnalyzer, path, parsers, *, store_dir: Path):
        super().__init__()
        self.analyzer = analyzer
        self.path = path
        self.parsers = list(parsers)
        self.store_dir = Path(store_dir)

    def run(self):
        out = {}
        try:
            self.analyzer.log_message = self.log_signal.emit
            for parser in self.parsers:
                pname = getattr(parser, "name", parser.__class__.__name__)
                self.log_signal.emit(f"[INFO] ===== 开始解析：{pname} =====\n")
                res = self.analyzer.analyze_stream(
                    self.path,
                    parser,
                    store_dir=self.store_dir,
                    on_init_cols=lambda cols, _p=pname: self.init_cols_signal.emit((_p, cols)),
                    on_batch=lambda rows, _p=pname: self.batch_rows_signal.emit((_p, rows)),
                    cancel_flag=None,
                )
                out[pname] = res
            self.result_signal.emit(out)
        except Exception as e:
            import traceback
            self.log_signal.emit(f"[ERROR] 分析失败：{e}\n{traceback.format_exc()}\n")
        finally:
            self.finished_signal.emit()


class CsvExportWorker(QThread):
    log_signal=Signal(str); done_signal=Signal(bool,str)
    def __init__(self, fp: str, store_path: str, cols: List[str]):
        super().__init__(); self.fp=fp; self.store_path=store_path; self.cols=cols
    def run(self):
        try:
            store = SqliteLogStore.open_existing(Path(self.store_path))
            total = store.count()
            self.log_signal.emit(f"[INFO] 开始导出CSV：{self.fp}（{total}行）\n")
            with open(self.fp,"w",newline="",encoding="utf-8-sig") as f:
                w=csv.writer(f)
                w.writerow(self.cols)
                written = 0
                for batch in store.iter_all(batch_size=5000):
                    for r in batch:
                        w.writerow(r)
                    written += len(batch)
                    if written % 20000 == 0:
                        self.log_signal.emit(f"[INFO] 导出进度：{written}/{total}\n")
            store.close()
            self.done_signal.emit(True,self.fp)
        except Exception as e:
            self.log_signal.emit(f"[ERROR] 导出CSV失败：{e}\n{traceback.format_exc()}\n")
            self.done_signal.emit(False,str(e))


class XlsxExportWorker(QThread):
    """Export multiple sqlite stores into one XLSX with multiple sheets.

    This replaces the previous "multiple csv files" behavior so users can get one
    spreadsheet with 2 sheets (Healthd/Vbat).
    """

    log_signal = Signal(str)
    done_signal = Signal(bool, str)

    def __init__(self, xlsx_fp: str, sheets: List[Tuple[str, str, List[str]]]):
        """sheets: List[(sheet_name, store_path, cols)]"""
        super().__init__()
        self.xlsx_fp = xlsx_fp
        self.sheets = sheets

    def run(self):
        try:
            from openpyxl import Workbook

            wb = Workbook()
            # remove default sheet, we will create explicitly
            if wb.sheetnames:
                ws0 = wb[wb.sheetnames[0]]
                wb.remove(ws0)

            for sheet_name, store_path, cols in self.sheets:
                store = SqliteLogStore.open_existing(Path(store_path))
                total = store.count()
                self.log_signal.emit(f"[INFO] 写入Sheet：{sheet_name}（{total}行）\n")
                ws = wb.create_sheet(title=sheet_name[:31])  # Excel limit
                ws.append(list(cols))
                written = 0
                for batch in store.iter_all(batch_size=5000):
                    for r in batch:
                        ws.append(list(r))
                    written += len(batch)
                    if written and written % 50000 == 0:
                        self.log_signal.emit(f"[INFO] {sheet_name} 进度：{written}/{total}\n")
                store.close()

            outp = Path(self.xlsx_fp)
            outp.parent.mkdir(parents=True, exist_ok=True)
            wb.save(outp)
            self.log_signal.emit(f"[INFO] XLSX 已导出：{self.xlsx_fp}\n")
            self.done_signal.emit(True, self.xlsx_fp)
        except Exception as e:
            self.log_signal.emit(f"[ERROR] 导出XLSX失败：{e}\n{traceback.format_exc()}\n")
            self.done_signal.emit(False, str(e))

class AdbPullWorker(QThread):
    log_signal=Signal(str); done_signal=Signal(bool,str)
    def __init__(self, serial:str, remote:str, out_dir:str):
        super().__init__(); self.serial=serial; self.remote=remote; self.out_dir=out_dir
    def run(self):
        if not self.serial: self.done_signal.emit(False,"未连接设备"); return
        outp=Path(self.out_dir); outp.mkdir(parents=True,exist_ok=True)
        cmd=adb_cmd(self.serial,["pull",self.remote,str(outp)])
        try:
            rc,out,err=run_cmd(cmd,timeout=900)
            self.done_signal.emit(rc==0, str(outp) if rc==0 else (err or out or f"adb pull失败 rc={rc}"))
        except Exception as e:
            self.log_signal.emit(f"[ERROR] 在线导出失败：{e}\n{traceback.format_exc()}\n")
            self.done_signal.emit(False, str(e))
