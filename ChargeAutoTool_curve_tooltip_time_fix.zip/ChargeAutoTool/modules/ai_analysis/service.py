# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Protocol, Sequence, Tuple, Iterable


@dataclass(frozen=True)
class Event:
    gid: int
    raw: str
    msg: str
    src_file: str
    line_no: Optional[int]
    ts: Optional[float]
    etype: str
    data: Dict[str, Any] = field(default_factory=dict)
    utc_dt: Optional[datetime] = None
    android_dt: Optional[datetime] = None


@dataclass
class Evidence:
    ts: Optional[float]
    line_no: Optional[int]
    msg: str
    src_file: str
    utc_dt: Optional[datetime] = None
    android_dt: Optional[datetime] = None

    def fmt(self) -> str:
        ts_str = f"{self.ts:.6f}" if self.ts is not None else "NA"
        ln_str = f"{self.line_no}" if self.line_no is not None else "NA"
        utc_str = self.utc_dt.strftime("%Y-%m-%d %H:%M:%S.%f UTC")[:-3] if self.utc_dt else "NA"
        return f"[k={ts_str}][utc={utc_str}][Line {ln_str}][{Path(self.src_file).name}] {self.msg}"


@dataclass
class SessionContext:
    t_framework_in: Optional[float] = None
    t_framework_out: Optional[float] = None
    t_hvdcp_running: Optional[float] = None
    t_pd_decision: Optional[float] = None
    t_tc30_fail: Optional[float] = None
    t_end_detect: Optional[float] = None

    t_framework_in_utc: Optional[datetime] = None
    t_framework_out_utc: Optional[datetime] = None
    t_hvdcp_running_utc: Optional[datetime] = None
    t_pd_decision_utc: Optional[datetime] = None
    t_tc30_fail_utc: Optional[datetime] = None
    t_end_detect_utc: Optional[datetime] = None

    session_state: str = "IDLE"
    pd_alg_state: Optional[str] = None
    pd_typec_only: bool = False
    pd_hard_reset_cnt: int = 0
    pd_vsafe0v_tout_cnt: int = 0
    tc30_attempted: bool = False
    tc30_locked: Optional[str] = None
    tc30_fail_reason: Optional[str] = None
    tc30_success_reason: Optional[str] = None
    hvdcp_running: bool = False

    saw_cc_open: bool = False
    saw_attached_null: bool = False
    saw_ps_insuff: bool = False

    pd_support: Optional[bool] = None
    pd_reason: Optional[str] = None
    tc30_support: Optional[bool] = None
    tc30_reason: Optional[str] = None
    phenomenon: Optional[str] = None
    sub_reason: Optional[str] = None
    end_mode: Optional[str] = None
    session_health: Optional[str] = None
    main_protocol: Optional[str] = None

    ev_insert: List[Evidence] = field(default_factory=list)
    ev_pd: List[Evidence] = field(default_factory=list)
    ev_tc30: List[Evidence] = field(default_factory=list)
    ev_hvdcp: List[Evidence] = field(default_factory=list)
    ev_plugout: List[Evidence] = field(default_factory=list)

    def duration(self) -> Optional[float]:
        if self.t_framework_in is None or self.t_framework_out is None:
            return None
        return self.t_framework_out - self.t_framework_in


@dataclass(frozen=True)
class SessionChunk:
    sid: int
    events: List[Event]
    seg_status: str


@dataclass(frozen=True)
class SessionResult:
    sid: int
    seg_status: str
    ctx: SessionContext
    report: str


@dataclass(frozen=True)
class AnalyzeRequest:
    input_path: str
    platform: str = "MTK"
    charge_arch: str = "1.0"
    profile: str = "MTK 默认"


class ProgressSink(Protocol):
    def __call__(self, message: str) -> None: ...


class ChargeAnalyzeUseCase:
    ORDERED_GROUPS = ("pl_lk", "kernel", "last_kernel")

    def __init__(self):
        self._repo = FlatLogRepository()

    def execute(self, req: AnalyzeRequest, progress: Optional[ProgressSink] = None) -> Dict[str, Any]:
        p = Path(req.input_path)
        if not p.exists():
            raise FileNotFoundError(f"路径不存在：{p}")

        groups = self._repo.collect(req.input_path)
        if progress:
            progress("[INFO] ===== 开始 AI 协议分析 =====")
            progress(f"[INFO] 输入路径: {p}")
        merged_sessions = []
        merged_timeline = []
        merged_evidence = []
        merged_report_parts = []
        summaries = []

        for gk in self.ORDERED_GROUPS:
            flist = groups.get(gk, [])
            if not flist:
                continue
            if progress:
                progress(f"[INFO] 分组 {gk}: {len(flist)} files")
                for fp in flist:
                    progress(f"    - {fp}")
            results, report = self._analyze_group(flist, req, group_title=f"{gk} ({len(flist)} files)", progress=progress)
            payload = self._results_to_payload(gk, results, report)
            summaries.append(payload["summary"])
            merged_sessions.extend(payload["sessions"])
            merged_timeline.extend(payload["protocol_timeline"])
            merged_evidence.extend(payload["evidence"])
            merged_report_parts.append(payload["report_text"])

        return {
            "summary": self._merge_summary(summaries),
            "sessions": merged_sessions,
            "protocol_timeline": merged_timeline,
            "evidence": merged_evidence,
            "report_text": "\n\n".join(merged_report_parts),
        }

    def _analyze_group(self, file_list: List[Path], req: AnalyzeRequest, group_title: str, progress: Optional[ProgressSink] = None):
        segmenter = StatefulSessionSegmenter()
        gid_base = 0
        results: List[SessionResult] = []

        for fp in file_list:
            if progress:
                progress(f"[INFO] 解析文件: {fp}")

            # pass 1: build time sync points (limited)
            try:
                with fp.open("r", encoding="utf-8", errors="ignore") as f:
                    tsync = TimeSyncBuilder().build(f, max_points=50)
            except Exception:
                tsync = None

            extractor = RegexEventExtractor(PROFILES.get(req.profile, DEFAULT_PROFILE), tsync)

            # pass 2: extract events with streaming + fast token filter
            try:
                with fp.open("r", encoding="utf-8", errors="ignore") as f:
                    events, gid_base = extractor.extract(f, str(fp), gid_base)
            except Exception as e:
                if progress:
                    progress(f"[WARN] 读取失败: {fp} err={e}")
                continue

            if not events:
                # 无关键事件，跳过 session 分割
                continue

            for ch in segmenter.feed(events):
                ctx = analyze_chunk(ch)
                report = TextRenderer().render_session(ctx, req.platform, req.charge_arch, group_title, f"Session S{ch.sid}")
                results.append(SessionResult(ch.sid, ch.seg_status, ctx, report))

        for ch in segmenter.flush():
            ctx = analyze_chunk(ch)
            report = TextRenderer().render_session(ctx, req.platform, req.charge_arch, group_title, f"Session S{ch.sid}")
            results.append(SessionResult(ch.sid, ch.seg_status, ctx, report))

        out = [TextRenderer().render_summary(results)] + [r.report for r in results]
        return results, "\n".join(out)

    @staticmethod
    def _merge_summary(summaries: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not summaries:
            return {"session_cnt": 0, "phenomenon": "NA", "sub_reason": "NA", "groups": []}
        total_cnt = sum(s.get("session_cnt", 0) for s in summaries)
        g0 = summaries[0]
        return {
            "session_cnt": total_cnt,
            "phenomenon": g0.get("phenomenon", "NA"),
            "sub_reason": g0.get("sub_reason", "NA"),
            "pd_supported": g0.get("pd_supported"),
            "tc30_supported": g0.get("tc30_supported"),
            "hvdcp_running": g0.get("hvdcp_running"),
            "groups": summaries,
        }

    @staticmethod
    def _ctx_to_protocol_timeline(ctx: SessionContext):
        pd_res = "OK" if ctx.pd_support else "FAIL" if ctx.pd_support is False else "NA"
        tc_res = "OK" if ctx.tc30_support else "FAIL" if ctx.tc30_support is False else "NA"
        hv_res = "OK" if ctx.hvdcp_running else "NA"
        return [
            ("PD", f"pd_support={ctx.pd_support} reason={ctx.pd_reason or 'NA'}", pd_res),
            ("TC30", f"tc30_support={ctx.tc30_support} reason={ctx.tc30_reason or 'NA'}", tc_res),
            ("HVDCP2.0", f"running={ctx.hvdcp_running}", hv_res),
        ]

    @staticmethod
    def _ctx_to_evidence(ctx: SessionContext):
        out = []
        for cat, evs, n, hint in [
            ("INSERT", ctx.ev_insert, 6, "插入链路"),
            ("PD", ctx.ev_pd, 8, "PD链路"),
            ("TC30", ctx.ev_tc30, 10, "TC30链路"),
            ("HVDCP", ctx.ev_hvdcp, 8, "HVDCP链路"),
            ("END", ctx.ev_plugout, 8, "结束链路"),
        ]:
            for e in evs[:n]:
                out.append((cat, e.fmt(), hint))
        return out

    def _results_to_payload(self, group_key: str, results: List[SessionResult], full_report: str):
        sessions, timeline, evidence = [], [], []
        for r in results:
            ctx = r.ctx
            t_in = ctx.t_framework_in_utc.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] if ctx.t_framework_in_utc else "NA"
            t_out = ctx.t_framework_out_utc.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] if ctx.t_framework_out_utc else "NA"
            end_reason = ctx.sub_reason or ctx.end_mode or r.seg_status
            sessions.append({
                "group": group_key, "id": r.sid, "t_in": t_in, "t_out": t_out,
                "phenomenon": ctx.phenomenon, "protocol": ctx.main_protocol,
                "health": ctx.session_health, "end_reason": end_reason,
            })
            timeline.extend(self._ctx_to_protocol_timeline(ctx))
            evidence.extend(self._ctx_to_evidence(ctx))
        c0 = results[0].ctx if results else SessionContext()
        return {
            "summary": {
                "group": group_key, "session_cnt": len(results), "phenomenon": c0.phenomenon or "NA",
                "sub_reason": c0.sub_reason or "NA", "pd_supported": c0.pd_support,
                "tc30_supported": c0.tc30_support, "hvdcp_running": c0.hvdcp_running,
            },
            "sessions": sessions, "protocol_timeline": timeline, "evidence": evidence, "report_text": full_report,
        }


class FlatLogRepository:
    def collect(self, input_path: str) -> Dict[str, List[Path]]:
        root = Path(input_path)
        groups = {"pl_lk": [], "kernel": [], "last_kernel": [], "other": []}

        def classify(p: Path):
            name = p.name.lower()
            if "pl_lk" in name:
                return "pl_lk"
            if "last_kernel" in name:
                return "last_kernel"
            if "kernel_" in name or name.startswith("kernel"):
                return "kernel"
            return "other"

        if root.is_file():
            groups[classify(root)].append(root)
        else:
            for fp in root.rglob("*"):
                if fp.is_file():
                    groups[classify(fp)].append(fp)
        for k in groups:
            groups[k].sort()
        return groups


class TimeSyncBuilder:
    def build(self, lines: Iterable[str], max_points: int = 50) -> Optional["TimeSynchronizer"]:
        """从日志中提取 UTC->Android 时间同步点。

        为了加速超大文件的分析，默认只采集最多 max_points 个同步点即可满足线性映射需求。
        """
        ts = TimeSynchronizer()
        ts.ingest_lines(lines, max_points=max_points)
        return ts if ts.points else None


class TimeSynchronizer:
    _re_kernel_ts = re.compile(r"\[\s*([\d.]+)\]")
    _re_sync = re.compile(r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d+)\s+UTC;android time\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d+)")

    def __init__(self):
        self.points: List[Tuple[float, float, float]] = []
        self.a = None
        self.b_utc = None
        self.b_android = None

    def ingest_lines(self, lines: Iterable[str], max_points: int = 50):
        for line in lines:
            m = self._re_sync.search(line)
            km = self._re_kernel_ts.search(line)
            if not m or not km:
                continue
            k = float(km.group(1))
            u = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=timezone.utc).timestamp()
            a = datetime.strptime(m.group(2), "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=timezone.utc).timestamp()
            self.points.append((k, u, a))
            if max_points and len(self.points) >= max_points:
                break
        if self.points:
            k, u, a = self.points[-1]
            self.a = 1.0
            self.b_utc = u - k
            self.b_android = a - k

    def kernel_to_utc(self, kernel_ts: Optional[float]) -> Optional[datetime]:
        if kernel_ts is None or self.a is None or self.b_utc is None:
            return None
        return datetime.fromtimestamp(self.a * kernel_ts + self.b_utc, tz=timezone.utc)

    def kernel_to_android(self, kernel_ts: Optional[float]) -> Optional[datetime]:
        if kernel_ts is None or self.a is None or self.b_android is None:
            return None
        return datetime.fromtimestamp(self.a * kernel_ts + self.b_android, tz=timezone.utc)


@dataclass(frozen=True)
class RegexProfile:
    name: str
    re_line_no: re.Pattern
    re_ts_bracket: re.Pattern
    re_ps_change: re.Pattern
    re_cc_alert: re.Pattern
    re_attached_arrow: re.Pattern
    re_charger_plug_in: re.Pattern
    re_charger_plug_out: re.Pattern
    re_pd_hreset: re.Pattern
    re_vsafe0v_tout: re.Pattern
    re_typec_only: re.Pattern
    re_pd_alg_ready: re.Pattern
    re_tc30_notifier: re.Pattern
    re_tc30_start_algo: re.Pattern
    re_tc30_set_failed: re.Pattern
    re_tc30_set_ok: re.Pattern
    re_tc30_run: re.Pattern
    re_hvdcp_running: re.Pattern


DEFAULT_PROFILE = RegexProfile(
    name="MTK 默认",
    re_line_no=re.compile(r"Line\s+(\d+):"),
    re_ts_bracket=re.compile(r"\[\s*([\d.]+)\]"),
    re_ps_change=re.compile(r"TCPC-TCPC:ps_change=(\d+)"),
    re_cc_alert=re.compile(r"TCPC-TYPEC:\[CC_Alert\]\s*(\d+)\/(\d+)"),
    re_attached_arrow=re.compile(r"TCPC-TYPEC:Attached->\s*(SINK|NULL)"),
    re_charger_plug_in=re.compile(r"pd_tcp_notifier_call Charger plug in"),
    re_charger_plug_out=re.compile(r"pd_tcp_notifier_call Charger plug out"),
    re_pd_hreset=re.compile(r"PD -> SNK_HRESET"),
    re_vsafe0v_tout=re.compile(r"VSafe0V TOUT"),
    re_typec_only=re.compile(r"TYPE-C Only Charger!"),
    re_pd_alg_ready=re.compile(r"\[ALG_PD\]pd_is_algo_ready state:\s*([A-Z0-9_]+)"),
    re_tc30_notifier=re.compile(r"\[ALG_TC30\]_tc30_notifier_call.*state:([A-Z0-9_]+)"),
    re_tc30_start_algo=re.compile(r"\[ALG_TC30\]_tc30_start_algo.*state:\s*(\d+)\s+([A-Z0-9_]+)\s+(\d+)"),
    re_tc30_set_failed=re.compile(r"\[ALG_TC30\]tc30_set_ta_vchr:\s*failed,.*vchr_after\s*=\s*(\d+)mV,.*target_vchr\s*=\s*(\d+)mV,.*ret_value:([-\d]+)"),
    re_tc30_set_ok=re.compile(r"\[ALG_TC30\]tc30_set_ta_vchr:\s*OK,.*vchr_target\s*=\s*(\d+)mV"),
    re_tc30_run=re.compile(r"\[ALG_TC30\]__tc30_run:"),
    re_hvdcp_running=re.compile(r"\[ALG_HVDCP20\]_hvdcp20_start_algo.*ALG_RUNNING"),
)

PROFILES = {DEFAULT_PROFILE.name: DEFAULT_PROFILE}


class RegexEventExtractor:
    def __init__(self, profile: RegexProfile, tsync: Optional[TimeSynchronizer]):
        self.p = profile
        self.tsync = tsync
        # 超大日志加速：先做 cheap substring filter，再进入 regex
        self._tokens = (
            "TCPC-", "TCPC:", "TCPC-TYPEC", "pd_tcp_notifier_call",
            "PD ->", "VSafe0V", "TYPE-C Only", "[ALG_PD]", "[ALG_TC30]", "[ALG_HVDCP20]"
        )

    def _parse_meta(self, line: str):
        line_no = None
        ts = None
        m = self.p.re_line_no.search(line)
        if m:
            line_no = int(m.group(1))
        m = self.p.re_ts_bracket.search(line)
        if m:
            ts = float(m.group(1))
        return line_no, ts, " ".join(line.strip().split())

    def _mk(self, gid, raw, msg, src_file, line_no, ts, etype, data):
        utc_dt = self.tsync.kernel_to_utc(ts) if self.tsync else None
        and_dt = self.tsync.kernel_to_android(ts) if self.tsync else None
        return Event(gid, raw, msg, src_file, line_no, ts, etype, data, utc_dt, and_dt)

    def extract(self, lines: Iterable[str], src_file: str, gid_base: int):
        events, gid, p = [], gid_base, self.p
        for raw in lines:
            # fast skip: 大量无关行直接跳过
            if not any(t in raw for t in self._tokens):
                continue
            line_no, ts, msg = self._parse_meta(raw)
            m = p.re_ps_change.search(msg)
            if m: events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "PS_CHANGE", {"ps_change": int(m.group(1))})); gid += 1; continue
            m = p.re_cc_alert.search(msg)
            if m: events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "CC_ALERT", {"b": int(m.group(2))})); gid += 1; continue
            m = p.re_attached_arrow.search(msg)
            if m: events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "TYPEC_ARROW", {"to": m.group(1)})); gid += 1; continue
            if p.re_charger_plug_in.search(msg): events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "CHARGER_PLUG_IN", {})); gid += 1; continue
            if p.re_charger_plug_out.search(msg): events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "CHARGER_PLUG_OUT", {})); gid += 1; continue
            if p.re_pd_hreset.search(msg): events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "PD_HRESET", {})); gid += 1; continue
            if p.re_vsafe0v_tout.search(msg): events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "PD_VSAFE0V_TOUT", {})); gid += 1; continue
            if p.re_typec_only.search(msg): events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "PD_TYPEC_ONLY", {})); gid += 1; continue
            m = p.re_pd_alg_ready.search(msg)
            if m: events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "PD_ALG_READY", {"pd_alg_state": m.group(1)})); gid += 1; continue
            m = p.re_tc30_notifier.search(msg)
            if m: events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "TC30_NOTIFIER", {"state": m.group(1)})); gid += 1; continue
            m = p.re_tc30_start_algo.search(msg)
            if m: events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "TC30_START_ALGO", {"state": m.group(2)})); gid += 1; continue
            m = p.re_tc30_set_ok.search(msg)
            if m: events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "TC30_SET_OK", {"target_mv": int(m.group(1))})); gid += 1; continue
            m = p.re_tc30_set_failed.search(msg)
            if m:
                after_mv, target_mv, ret = int(m.group(1)), int(m.group(2)), int(m.group(3))
                events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "TC30_SET_FAIL_DETAIL", {"after_mv": after_mv, "target_mv": target_mv, "ret": ret, "gap_mv": target_mv - after_mv})); gid += 1; continue
            if p.re_tc30_run.search(msg): events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "TC30_RUN", {})); gid += 1; continue
            if p.re_hvdcp_running.search(msg): events.append(self._mk(gid, raw, msg, src_file, line_no, ts, "HVDCP_RUNNING", {})); gid += 1; continue
        return events, gid


class StatefulSessionSegmenter:
    def __init__(self):
        self._cur, self._active, self._sid = [], False, 0

    @property
    def sid(self):
        return self._sid

    def feed(self, events: List[Event]):
        chunks = []

        def close(status):
            if self._cur:
                self._sid += 1
                chunks.append(SessionChunk(self._sid, self._cur[:], status))
                self._cur.clear()
                self._active = False

        # Some logs do not contain explicit plug-in/plug-out markers.
        # In that case we still want to form a session so that "协议轨迹/证据" has output.
        def is_protocol_event(e: Event) -> bool:
            return (
                e.etype.startswith("PD_")
                or e.etype.startswith("TC30_")
                or e.etype in ("HVDCP_RUNNING", "CC_ALERT", "PS_CHANGE", "TYPEC_ARROW")
            )

        for ev in events:
            if ev.etype == "CHARGER_PLUG_IN":
                if self._active:
                    close("INCOMPLETE")
                self._active = True
                self._cur.append(ev)
                continue

            # Implicit session start when plug markers are missing
            if not self._active and is_protocol_event(ev):
                self._active = True
                self._cur.append(ev)
                continue

            if self._active:
                self._cur.append(ev)
                if ev.etype == "CHARGER_PLUG_OUT":
                    close("NORMAL")
        return chunks

    def flush(self):
        if self._active and self._cur:
            self._sid += 1
            ch = SessionChunk(self._sid, self._cur[:], "INCOMPLETE")
            self._cur.clear()
            self._active = False
            return [ch]
        return []


def ev_to_evidence(ev: Event):
    return Evidence(ev.ts, ev.line_no, ev.msg, ev.src_file, ev.utc_dt, ev.android_dt)


def set_time_once(ctx: SessionContext, ts_attr: str, utc_attr: str, ev: Event):
    if ev.ts is not None and getattr(ctx, ts_attr) is None:
        setattr(ctx, ts_attr, ev.ts)
        setattr(ctx, utc_attr, ev.utc_dt)


class PdAnalyzer:
    def on_event(self, ev: Event, ctx: SessionContext):
        if ev.etype.startswith("PD_"):
            ctx.ev_pd.append(ev_to_evidence(ev))
        if ev.etype == "PD_HRESET":
            ctx.pd_hard_reset_cnt += 1
        elif ev.etype == "PD_VSAFE0V_TOUT":
            ctx.pd_vsafe0v_tout_cnt += 1
        elif ev.etype == "PD_TYPEC_ONLY":
            ctx.pd_typec_only = True
            set_time_once(ctx, "t_pd_decision", "t_pd_decision_utc", ev)
        elif ev.etype == "PD_ALG_READY":
            ctx.pd_alg_state = ev.data.get("pd_alg_state")

    def finalize(self, ctx: SessionContext):
        if ctx.pd_alg_state == "ALG_TA_NOT_SUPPORT":
            ctx.pd_support, ctx.pd_reason = False, "ALG_TA_NOT_SUPPORT"
        elif ctx.pd_typec_only:
            ctx.pd_support, ctx.pd_reason = False, "TYPE-C Only Charger"
        elif ctx.pd_hard_reset_cnt > 0 and ctx.pd_vsafe0v_tout_cnt > 0:
            ctx.pd_support, ctx.pd_reason = False, "HRESET+VSafe0V_TOUT"
        else:
            ctx.pd_support, ctx.pd_reason = True, None


class Tc30Analyzer:
    def on_event(self, ev: Event, ctx: SessionContext):
        if not ev.etype.startswith("TC30_"):
            return
        ctx.tc30_attempted = True
        ctx.ev_tc30.append(ev_to_evidence(ev))
        if ev.etype == "TC30_NOTIFIER" and ev.data.get("state") == "ALG_TA_NOT_SUPPORT":
            ctx.tc30_locked, ctx.tc30_fail_reason = "FAIL", "ALG_TA_NOT_SUPPORT"
        elif ev.etype == "TC30_SET_FAIL_DETAIL":
            if int(ev.data.get("ret", 0)) < 0:
                ctx.tc30_locked, ctx.tc30_fail_reason = "FAIL", f"SET_VCHR_FAIL ret={ev.data.get('ret')}"
        elif ev.etype in ("TC30_START_ALGO", "TC30_RUN") and ev.data.get("state", "ALG_RUNNING") == "ALG_RUNNING":
            if ctx.tc30_locked != "FAIL":
                ctx.tc30_locked, ctx.tc30_success_reason = "SUCCESS", "ALG_RUNNING"
        if ctx.tc30_locked == "FAIL":
            set_time_once(ctx, "t_tc30_fail", "t_tc30_fail_utc", ev)

    def finalize(self, ctx: SessionContext):
        if not ctx.tc30_attempted:
            ctx.tc30_support, ctx.tc30_reason = None, "NO_TC30_LOG"
        elif ctx.tc30_locked == "SUCCESS":
            ctx.tc30_support, ctx.tc30_reason = True, ctx.tc30_success_reason or "SUCCESS_LOCKED"
        elif ctx.tc30_locked == "FAIL":
            ctx.tc30_support, ctx.tc30_reason = False, ctx.tc30_fail_reason or "FAIL_LOCKED"
        else:
            ctx.tc30_support, ctx.tc30_reason = False, "NO_SUCCESS_EVIDENCE"


class HvdcpAnalyzer:
    def on_event(self, ev: Event, ctx: SessionContext):
        if ev.etype == "HVDCP_RUNNING":
            ctx.hvdcp_running = True
            set_time_once(ctx, "t_hvdcp_running", "t_hvdcp_running_utc", ev)
            ctx.ev_hvdcp.append(ev_to_evidence(ev))

    def finalize(self, ctx: SessionContext):
        pass


class VbusAnalyzer:
    def on_event(self, ev: Event, ctx: SessionContext):
        if ev.etype == "CHARGER_PLUG_IN":
            set_time_once(ctx, "t_framework_in", "t_framework_in_utc", ev)
            ctx.ev_insert.append(ev_to_evidence(ev))
        elif ev.etype == "CHARGER_PLUG_OUT":
            set_time_once(ctx, "t_framework_out", "t_framework_out_utc", ev)
            ctx.ev_plugout.append(ev_to_evidence(ev))
        elif ev.etype == "CC_ALERT" and int(ev.data.get("b", -1)) == 0:
            ctx.saw_cc_open = True
            set_time_once(ctx, "t_end_detect", "t_end_detect_utc", ev)
            ctx.ev_plugout.append(ev_to_evidence(ev))
        elif ev.etype == "TYPEC_ARROW" and ev.data.get("to") == "NULL":
            ctx.saw_attached_null = True
            set_time_once(ctx, "t_end_detect", "t_end_detect_utc", ev)
            ctx.ev_plugout.append(ev_to_evidence(ev))
        elif ev.etype == "PS_CHANGE" and int(ev.data.get("ps_change", -1)) == 1:
            ctx.saw_ps_insuff = True
            set_time_once(ctx, "t_end_detect", "t_end_detect_utc", ev)
            ctx.ev_plugout.append(ev_to_evidence(ev))

    def finalize(self, ctx: SessionContext):
        pass


class PhenomenonClassifier:
    def on_event(self, ev: Event, ctx: SessionContext):
        pass

    def finalize(self, ctx: SessionContext):
        has_out = ctx.t_framework_out is not None
        has_detach = ctx.saw_cc_open or ctx.saw_attached_null
        if has_out and has_detach:
            ctx.end_mode = "拔出"
        elif has_out:
            ctx.end_mode = "plug out（detach证据缺失）"
        else:
            ctx.end_mode = "INCOMPLETE"

        if ctx.hvdcp_running:
            ctx.main_protocol = "HVDCP2.0"
            ctx.session_health = "正常"
            ctx.phenomenon = "正常HVDCP充电，无异常"
            ctx.sub_reason = f"结束方式：{ctx.end_mode}"
            return
        if ctx.tc30_support is True:
            ctx.main_protocol = "TC30"
            ctx.session_health = "正常"
            ctx.phenomenon = "正常TC30充电，无异常"
            ctx.sub_reason = f"TC30证据：{ctx.tc30_reason or 'NA'}；结束方式：{ctx.end_mode}"
            return
        ctx.main_protocol = "PD" if ctx.pd_support else "NA"
        if ctx.tc30_attempted and ctx.tc30_support is False:
            ctx.session_health = "未分类"
            ctx.phenomenon = "TC30未进入运行态（不支持/协商失败/回退）"
            ctx.sub_reason = f"TC30原因：{ctx.tc30_reason or 'NA'}；结束方式：{ctx.end_mode}"
            return
        ctx.session_health = "未分类"
        ctx.phenomenon = "未分类"
        ctx.sub_reason = f"规则未覆盖；结束方式：{ctx.end_mode}"


def analyze_chunk(ch: SessionChunk) -> SessionContext:
    ctx = SessionContext()
    analyzers = [VbusAnalyzer(), PdAnalyzer(), Tc30Analyzer(), HvdcpAnalyzer(), PhenomenonClassifier()]
    for ev in ch.events:
        for a in analyzers:
            a.on_event(ev, ctx)
    for a in analyzers:
        a.finalize(ctx)
    return ctx


class TextRenderer:
    def render_session(self, ctx: SessionContext, platform: str, charge_arch: str, log_group_title: str, session_title: str) -> str:
        d = ctx.duration()
        dur = f"{d:.2f}s" if d is not None else "NA"
        return "\n".join([
            session_title,
            f"平台={platform}, 架构={charge_arch}, 分组={log_group_title}",
            f"现象={ctx.phenomenon}",
            f"主协议={ctx.main_protocol}",
            f"结束={ctx.end_mode}",
            f"时长={dur}",
        ])

    def render_summary(self, results: List[SessionResult]) -> str:
        lines = ["【Session 摘要】"]
        for r in results:
            lines.append(f"S{r.sid}: {r.ctx.main_protocol or 'NA'} / {r.ctx.phenomenon or 'NA'} / {r.ctx.end_mode or r.seg_status}")
        return "\n".join(lines)
