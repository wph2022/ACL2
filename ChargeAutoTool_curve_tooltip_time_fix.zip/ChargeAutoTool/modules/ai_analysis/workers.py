import traceback
from PySide6.QtCore import QThread, Signal
from ChargeAutoTool.modules.ai_analysis.service import ChargeAnalyzeUseCase, AnalyzeRequest


class AiAnalyzeWorker(QThread):
    progress = Signal(str)
    result = Signal(object)
    failed = Signal(str)

    def __init__(self, req: AnalyzeRequest):
        super().__init__()
        self.req = req
        self.usecase = ChargeAnalyzeUseCase()

    def run(self):
        try:
            out = self.usecase.execute(self.req, progress=self.progress.emit)
            self.result.emit(out)
        except Exception as e:
            self.failed.emit(f"{e}\n{traceback.format_exc()}")
