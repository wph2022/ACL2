from typing import List, Tuple
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QTabWidget, QLabel, QTableWidget, QTableWidgetItem, QPlainTextEdit
from ChargeAutoTool.config import UI


class AiResults(QWidget):
    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(UI.GAP)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)

        self.summary = QLabel("尚未分析")
        self.summary.setWordWrap(True)
        self.summary.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        w1 = QWidget(); l1 = QVBoxLayout(w1); l1.addWidget(self.summary); l1.addStretch(1)

        self.sessions = QTableWidget(0, 8)
        self.sessions.setHorizontalHeaderLabels(["Group", "ID", "t_in", "t_out", "Protocol", "Health", "Phenomenon", "End/Reason"])
        w2 = QWidget(); l2 = QVBoxLayout(w2); l2.addWidget(self.sessions)

        self.timeline = QTableWidget(0, 3)
        self.timeline.setHorizontalHeaderLabels(["协议", "轨迹/结论", "结果"])
        w3 = QWidget(); l3 = QVBoxLayout(w3); l3.addWidget(self.timeline)

        self.evidence = QTableWidget(0, 3)
        self.evidence.setHorizontalHeaderLabels(["类别", "证据", "备注"])
        w4 = QWidget(); l4 = QVBoxLayout(w4); l4.addWidget(self.evidence)

        self.report = QPlainTextEdit(); self.report.setReadOnly(True)
        w5 = QWidget(); l5 = QVBoxLayout(w5); l5.addWidget(self.report)

        self.runlog = QPlainTextEdit(); self.runlog.setReadOnly(True); self.runlog.setPlainText("运行日志.")

        self.tabs.addTab(w1, "结论概览")
        self.tabs.addTab(w2, "Session")
        self.tabs.addTab(w3, "协议轨迹")
        self.tabs.addTab(w4, "证据")
        self.tabs.addTab(w5, "报告")
        self.tabs.addTab(self.runlog, "运行日志")

    def append_log(self, msg: str):
        self.runlog.appendPlainText(msg.rstrip())

    def clear_all(self):
        self.summary.setText("尚未分析")
        for t in (self.sessions, self.timeline, self.evidence):
            t.setRowCount(0)
        self.report.setPlainText("")
        self.runlog.setPlainText("运行日志.")

    def set_payload(self, data: dict):
        s = data.get("summary", {})
        lines = [
            f"Session 数量: {s.get('session_cnt', '-')}",
            f"现象分类: {s.get('phenomenon', '-')}",
            f"子原因: {s.get('sub_reason', '-')}",
            f"PD 支持: {s.get('pd_supported', '-')}",
            f"TC30 支持: {s.get('tc30_supported', '-')}",
            f"HVDCP 运行: {s.get('hvdcp_running', '-')}",
        ]
        self.summary.setText("\n".join(lines))
        self._fill_sessions(data.get("sessions", []))
        self._fill_3col(self.timeline, data.get("protocol_timeline", []))
        self._fill_3col(self.evidence, data.get("evidence", []))
        self.report.setPlainText(data.get("report_text", ""))

    def _fill_sessions(self, rows: List[dict]):
        self.sessions.setRowCount(0)
        for row in rows:
            r = self.sessions.rowCount(); self.sessions.insertRow(r)
            vals = [row.get("group", ""), row.get("id", ""), row.get("t_in", ""), row.get("t_out", ""), row.get("protocol", ""), row.get("health", ""), row.get("phenomenon", ""), row.get("end_reason", "")]
            for c, v in enumerate(vals):
                self.sessions.setItem(r, c, QTableWidgetItem(str(v)))

    def _fill_3col(self, tbl: QTableWidget, rows: List[Tuple[str, str, str]]):
        tbl.setRowCount(0)
        for a, b, cval in rows:
            r = tbl.rowCount(); tbl.insertRow(r)
            tbl.setItem(r, 0, QTableWidgetItem(str(a)))
            tbl.setItem(r, 1, QTableWidgetItem(str(b)))
            tbl.setItem(r, 2, QTableWidgetItem(str(cval)))
