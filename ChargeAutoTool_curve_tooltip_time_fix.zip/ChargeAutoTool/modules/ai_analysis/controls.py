from pathlib import Path
from typing import Optional
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QGroupBox, QGridLayout, QPushButton, QFileDialog, QMessageBox, QComboBox
from ChargeAutoTool.config import UI
from ChargeAutoTool.ui.widgets.drop_line_edit import DropLineEdit
from ChargeAutoTool.modules.ai_analysis.results import AiResults
from ChargeAutoTool.modules.ai_analysis.service import AnalyzeRequest, PROFILES
from ChargeAutoTool.modules.ai_analysis.workers import AiAnalyzeWorker


class AiControls(QWidget):
    def __init__(self, host):
        super().__init__()
        self.host = host
        self.results: Optional[AiResults] = None
        self.worker: Optional[AiAnalyzeWorker] = None
        self._build()

    def attach_results(self, r: AiResults):
        self.results = r

    def _op(self, msg: str):
        hasattr(self.host, "log_operation") and self.host.log_operation(f"[AI协议分析] {msg}")

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(UI.GAP)
        root.addWidget(QLabel("AI充电协议分析（会话化）"))

        box = QGroupBox("操作区")
        g = QGridLayout(box)
        g.setHorizontalSpacing(8); g.setVerticalSpacing(8); g.setColumnStretch(1, 1)

        self.path = DropLineEdit("选择日志文件或目录")
        self.pick = QPushButton("选择")
        self.pick.setProperty("role", "secondary")
        self.pick.clicked.connect(self._pick_path)

        self.profile = QComboBox()
        self.profile.addItems(list(PROFILES.keys()))
        self.btn_run = QPushButton("开始分析")
        self.btn_clear = QPushButton("清除")
        self.btn_clear.setProperty("role", "danger")
        self.btn_run.clicked.connect(self.on_run)
        self.btn_clear.clicked.connect(self.on_clear)

        g.addWidget(QLabel("输入路径"), 0, 0)
        g.addWidget(self.path, 0, 1)
        g.addWidget(self.pick, 0, 2)
        g.addWidget(QLabel("Profile"), 1, 0)
        g.addWidget(self.profile, 1, 1)
        g.addWidget(self.btn_run, 2, 0)
        g.addWidget(self.btn_clear, 2, 1)

        root.addWidget(box)
        root.addStretch(1)

    def _pick_path(self):
        fp, _ = QFileDialog.getOpenFileName(self, "选择日志文件", "", "Log (*.log *.txt);;All(*.*)")
        if fp:
            self.path.setText(fp)
            return
        dp = QFileDialog.getExistingDirectory(self, "选择日志目录")
        if dp:
            self.path.setText(dp)

    def _busy(self, b: bool):
        for w in (self.path, self.pick, self.profile, self.btn_run):
            w.setEnabled(not b)

    def on_clear(self):
        self.path.setText("")
        self.results and self.results.clear_all()

    def on_run(self):
        p = Path(self.path.text().strip())
        if not p.exists():
            QMessageBox.warning(self, "提示", "路径不存在")
            return
        if self.worker and self.worker.isRunning():
            return

        req = AnalyzeRequest(input_path=str(p), profile=self.profile.currentText())
        self.worker = AiAnalyzeWorker(req)
        self.worker.progress.connect(lambda s: self.results and self.results.append_log(s))
        self.worker.failed.connect(self._on_fail)
        self.worker.result.connect(self._on_result)
        self.worker.finished.connect(lambda: self._busy(False))

        self._busy(True)
        self.results and self.results.append_log("开始分析...")
        self._op(f"开始分析 path={p}")
        self.worker.start()

    def _on_fail(self, err: str):
        self.results and self.results.append_log(f"[ERROR] {err}")
        self._op(f"分析失败 err={err.splitlines()[0] if err else 'unknown'}")
        QMessageBox.critical(self, "分析失败", err.splitlines()[0] if err else "未知错误")

    def _on_result(self, data: dict):
        self.results and self.results.set_payload(data)
        self.results and self.results.append_log("分析完成")
        self._op("分析完成")
