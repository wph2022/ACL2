from typing import Optional
from PySide6.QtWidgets import QWidget,QVBoxLayout,QLabel,QGroupBox,QHBoxLayout,QGridLayout,QLineEdit,QPushButton,QMessageBox
from ChargeAutoTool.config import UI
from ChargeAutoTool.ui.widgets.dashed_frame import DashedFrame
from ChargeAutoTool.modules.register_analysis.workers import ShellCmdWorker

class RegControls(QWidget):
    def __init__(self, host):
        super().__init__(); self.host=host; self.worker: Optional[ShellCmdWorker]=None; self.results=None; self._build()
    def attach_results(self,r): self.results=r
    def set_device_status(self,s:str): self.dev_label.setText(s)
    def _log(self,msg:str): self.results and self.results.append_log(msg)
    def _op(self,msg:str): hasattr(self.host, "log_operation") and self.host.log_operation(f"[寄存器分析] {msg}")
    def _serial(self):
        s=self.host.device_serial()
        if not s: self._op("操作失败: 没有唯一在线设备"); QMessageBox.warning(self,"提示","没有唯一在线设备（请只连接一台）。"); return None
        return s
    def _run(self, serial, cmd, timeout, on_done):
        self._op(f"执行命令 serial={serial}, timeout={timeout}, cmd={cmd}"); self.worker=ShellCmdWorker(serial,cmd,timeout=timeout); self.worker.log_signal.connect(self._log); self.worker.done_signal.connect(on_done)
        self.worker.done_signal.connect(lambda rc,out,err,cmd_str,root: self._op(f"命令完成 rc={rc}, cmd={cmd_str}"))
        # bus event (decoupled)
        bus = getattr(self.host, "bus", None)
        if bus is not None:
            try:
                self.worker.done_signal.connect(lambda rc,out,err,cmd_str,root: bus.publish("reg.done", rc=int(rc), cmd=str(cmd_str)))
            except Exception:
                pass
        tr = getattr(self.host, "task_runner", None)
        if tr is not None:
            try:
                tr.submit("寄存器命令", self.worker, meta={"cmd": cmd, "timeout": timeout})
                return
            except Exception:
                pass
        self.worker.start()
    def _cmd_get(self,bus,addr,reg): return f"i2cget -f -y {bus} {addr} {reg}"
    def _cmd_set(self,bus,addr,reg,val): return f"i2cset -f -y {bus} {addr} {reg} {val} b"
    def _cmd_dump(self,bus,addr): return f"i2cdump -f -y {bus} {addr} b"
    def _build(self):
        root=QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(UI.GAP)
        root.addWidget(QLabel("寄存器分析（I2C）"))
        dev=QGroupBox("设备"); dh=QHBoxLayout(dev); df=DashedFrame(); dl=QHBoxLayout(df); self.dev_label=QLabel("未连接"); dl.addWidget(self.dev_label,1); dh.addWidget(df,1); root.addWidget(dev)
        cfg=QGroupBox("设备参数配置"); g=QGridLayout(cfg); g.setHorizontalSpacing(8); g.setVerticalSpacing(8); self.bus=QLineEdit("7"); self.addr=QLineEdit("0x55"); self.reg=QLineEdit("0x10"); self.val=QLineEdit("0x00")
        g.addWidget(QLabel("I2C Bus"),0,0); g.addWidget(self.bus,0,1); g.addWidget(QLabel("从地址"),1,0); g.addWidget(self.addr,1,1); g.addWidget(QLabel("寄存器"),2,0); g.addWidget(self.reg,2,1); g.addWidget(QLabel("写入值"),3,0); g.addWidget(self.val,3,1); root.addWidget(cfg)
        op=QGroupBox("操作按钮"); oh=QHBoxLayout(op); oh.setSpacing(8); self.b_read=QPushButton("读寄存器"); self.b_write=QPushButton("写寄存器"); self.b_write.setProperty("role", "secondary"); self.b_dump=QPushButton("i2cDUMP"); self.b_dump.setProperty("role", "secondary"); self.b_clear=QPushButton("清除显示"); self.b_clear.setProperty("role", "danger")
        self.b_read.clicked.connect(self.on_read); self.b_write.clicked.connect(self.on_write); self.b_dump.clicked.connect(self.on_dump); self.b_clear.clicked.connect(lambda: (self._op("用户点击清除显示"), self.results and self.results.clear_all()))
        [oh.addWidget(b) for b in (self.b_read,self.b_write,self.b_dump,self.b_clear)]; root.addWidget(op); root.addStretch(1)
    def on_read(self):
        s=self._serial();
        if not s: return
        cmd=self._cmd_get(self.bus.text().strip() or "7",self.addr.text().strip() or "0x55",self.reg.text().strip() or "0x10")
        self._run(s,cmd,8,lambda rc,out,err,cmd_str,root: self.results and self.results.set_detail("I2C READ",f"cmd: {cmd_str}\nrc: {rc}\nstdout:\n{out}\nstderr:\n{err}"))
    def on_write(self):
        s=self._serial();
        if not s: return
        cmd=self._cmd_set(self.bus.text().strip() or "7",self.addr.text().strip() or "0x55",self.reg.text().strip() or "0x10",self.val.text().strip() or "0x00")
        self._run(s,cmd,8,lambda rc,out,err,cmd_str,root: self.results and self.results.set_detail("I2C WRITE",f"cmd: {cmd_str}\nrc: {rc}\nstdout:\n{out}\nstderr:\n{err}"))
    def on_dump(self):
        s=self._serial();
        if not s: return
        cmd=self._cmd_dump(self.bus.text().strip() or "7",self.addr.text().strip() or "0x55")
        self._run(s,cmd,12,lambda rc,out,err,cmd_str,root: self.results and self.results.set_detail("I2C DUMP",f"cmd: {cmd_str}\nrc: {rc}\nstdout:\n{out}\nstderr:\n{err}"))
