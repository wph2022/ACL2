from PySide6.QtWidgets import QWidget,QVBoxLayout,QTextEdit
from ChargeAutoTool.config import UI

class RegResults(QWidget):
    def __init__(self):
        super().__init__(); root=QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(UI.GAP)
        self.detail=QTextEdit(); self.detail.setReadOnly(True); self.detail.setPlainText("暂无执行操作"); root.addWidget(self.detail,1)
        self.runlog=QTextEdit(); self.runlog.setReadOnly(True); self.runlog.setPlainText("暂无执行操作"); root.addWidget(self.runlog,0)
    def set_detail(self, title:str, body:str): self.detail.setPlainText(f"{title}\n{'='*max(12,len(title))}\n{body}\n")
    def clear_all(self): self.detail.setPlainText("暂无执行操作"); self.runlog.setPlainText("暂无执行操作")
    def append_log(self,msg:str): self.runlog.append(msg.rstrip())
