import traceback
from PySide6.QtCore import QThread, Signal
from ChargeAutoTool.modules.register_analysis.i2c_service import run_shell_with_root

class ShellCmdWorker(QThread):
    log_signal = Signal(str)
    done_signal = Signal(int, str, str, str, str)
    def __init__(self, serial: str, shell_cmd: str, timeout: int = 8, auto_root: bool = True):
        super().__init__(); self.serial=serial; self.shell_cmd=shell_cmd; self.timeout=timeout
    def run(self):
        try:
            rc, out, err = run_shell_with_root(self.serial, self.shell_cmd, timeout=self.timeout)
            self.done_signal.emit(rc, out, err, self.shell_cmd, "auto")
        except Exception as e:
            self.log_signal.emit(f"[ERROR] 执行失败: {e}\n{traceback.format_exc()}")
            self.done_signal.emit(-1, "", str(e), self.shell_cmd, "auto")
