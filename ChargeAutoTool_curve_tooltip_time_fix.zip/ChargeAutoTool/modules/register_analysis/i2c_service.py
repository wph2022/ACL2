from ChargeAutoTool.core.adb import adb_cmd, adb_root, su_root_ok, is_permission_denied
from ChargeAutoTool.utils.helpers import run_cmd

def run_shell_with_root(serial: str, shell_cmd: str, timeout: int = 8):
    cmd_plain = adb_cmd(serial, ["shell", shell_cmd])
    rc, out, err = run_cmd(cmd_plain, timeout=timeout)
    if is_permission_denied(out, err):
        ok, _ = adb_root(serial)
        if ok: return run_cmd(cmd_plain, timeout=timeout)
        if su_root_ok(serial): return run_cmd(adb_cmd(serial, ["shell", "su", "-c", shell_cmd]), timeout=timeout)
    return rc, out, err
