from typing import List, Tuple
from ChargeAutoTool.utils.helpers import run_cmd

def adb_cmd(serial: str, args: List[str]) -> List[str]:
    return (["adb", "-s", serial] if serial else ["adb"]) + args

def list_adb_devices() -> List[str]:
    rc, out, _ = run_cmd(["adb", "devices"], timeout=8)
    if rc != 0: return []
    devs = []
    for ln in out.splitlines():
        ln = ln.strip()
        if not ln or ln.startswith("List of devices"): continue
        ps = ln.split()
        if len(ps) >= 2 and ps[1] == "device": devs.append(ps[0])
    return devs

def adb_root(serial: str) -> Tuple[bool, str]:
    rc, out, err = run_cmd(adb_cmd(serial, ["root"]), timeout=8)
    msg = (out + "\n" + err).strip()
    return (rc == 0) and ("root" in msg.lower()), msg

def su_root_ok(serial: str) -> bool:
    rc, out, err = run_cmd(adb_cmd(serial, ["shell", "su", "-c", "id"]), timeout=6)
    s = (out + "\n" + err).lower()
    return (rc == 0) and ("uid=0" in s)

def is_permission_denied(stdout: str, stderr: str) -> bool:
    s = (stdout + "\n" + stderr).lower()
    return ("permission denied" in s) or ("not permitted" in s)
