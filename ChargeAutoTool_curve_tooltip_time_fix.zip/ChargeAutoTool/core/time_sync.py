import datetime as dt
import re
from pathlib import Path
from typing import List, Optional, Tuple

class TimeSyncEstimator:
    _re_k = re.compile(r"\[\s*(\d+(?:\.\d+)?)\s*\]")
    _re_dt = re.compile(r"\b(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?)\b")
    _re_tag = re.compile(r"android\s*time\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?)", re.I)
    def __init__(self):
        self.offset_seconds: Optional[float] = None
        self.samples: List[float] = []
    @staticmethod
    def _pdt(s: str) -> Optional[dt.datetime]:
        for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"):
            try: return dt.datetime.strptime(s.strip(), fmt)
            except Exception: pass
        return None
    def _anchor(self, line: str) -> Optional[Tuple[float, dt.datetime]]:
        mk = self._re_k.search(line)
        if not mk: return None
        try: k = float(mk.group(1))
        except Exception: return None
        for m in (self._re_tag.search(line), self._re_dt.search(line)):
            if m:
                d = self._pdt(m.group(1))
                if d: return k, d
        return None
    def fit(self, files: List[Path], log=lambda m: None, max_lines: int = 250000, max_a: int = 60):
        self.offset_seconds = None; self.samples = []
        a = 0
        for fp in files:
            n = fp.name.lower()
            if "kernel" not in n and "kmsg" not in n: continue
            try:
                with fp.open("r", encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f):
                        if i >= max_lines: break
                        low = line.lower()
                        if "android time" not in low and " utc" not in low: continue
                        an = self._anchor(line)
                        if not an: continue
                        k, d = an
                        self.samples.append(d.timestamp() - k)
                        a += 1
                        if a >= max_a: break
            except Exception as e:
                log(f"[WARN] TimeSync 读取失败：{fp} ({e})\n")
            if a >= max_a: break
        if not self.samples: return
        s = sorted(self.samples); mid = len(s)//2
        self.offset_seconds = s[mid] if len(s)%2 else (s[mid-1]+s[mid])/2.0
    def k2a(self, ksec: float) -> str:
        if self.offset_seconds is None: return ""
        try:
            d = dt.datetime.fromtimestamp(ksec + self.offset_seconds)
            us = int(round((ksec - int(ksec))*1_000_000))
            return d.replace(microsecond=us).strftime("%Y-%m-%d %H:%M:%S.%f")
        except Exception: return ""
