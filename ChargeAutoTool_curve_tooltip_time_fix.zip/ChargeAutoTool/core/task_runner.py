# -*- coding: utf-8 -*-
"""TaskRunner: minimal unified lifecycle tracking for QThread-based workers.

This implementation is intentionally conservative to keep changes small:
- Accepts existing QThread workers as-is.
- Tracks task id/name, routes lifecycle to Qt signals.
- Optionally publishes events to EventBus (if provided).

It does NOT enforce a new worker interface; however, if a worker provides:
    - cancel(): called when cancel_task(task_id) is invoked
    - finished_signal: Signal() (in addition to QThread.finished)
we will listen to it as well.
"""

from __future__ import annotations

import traceback
import uuid
from dataclasses import dataclass
from typing import Any, Dict, Optional

from PySide6.QtCore import QObject, Signal, QThread

try:
    from ChargeAutoTool.app.bus import EventBus
except Exception:  # pragma: no cover
    EventBus = None  # type: ignore


@dataclass
class TaskInfo:
    task_id: str
    name: str
    worker: QThread
    meta: Dict[str, Any]


class TaskRunner(QObject):
    task_started = Signal(str, str)              # (task_id, name)
    task_finished = Signal(str, str)             # (task_id, name)
    task_failed = Signal(str, str, str)          # (task_id, name, err)
    task_canceled = Signal(str, str)             # (task_id, name)

    def __init__(self, bus: Optional["EventBus"] = None, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.bus = bus
        self._tasks: Dict[str, TaskInfo] = {}

    def submit(self, name: str, worker: QThread, *, meta: Optional[Dict[str, Any]] = None) -> str:
        """Start a worker and track it."""
        tid = uuid.uuid4().hex[:10]
        info = TaskInfo(task_id=tid, name=name, worker=worker, meta=dict(meta or {}))
        self._tasks[tid] = info

        self.task_started.emit(tid, name)
        if self.bus is not None:
            self.bus.publish("task.started", task_id=tid, name=name, meta=info.meta)

        # Hook completion: prefer custom finished_signal if present, otherwise QThread.finished.
        if hasattr(worker, "finished_signal"):
            try:
                getattr(worker, "finished_signal").connect(lambda: self._on_finished(tid))
            except Exception:
                pass
        worker.finished.connect(lambda: self._on_finished(tid))

        # If worker exposes an error signal, allow integration. (Optional)
        if hasattr(worker, "error_signal"):
            try:
                getattr(worker, "error_signal").connect(lambda err: self._on_failed(tid, str(err)))
            except Exception:
                pass

        worker.start()
        return tid

    def cancel_task(self, task_id: str) -> bool:
        info = self._tasks.get(task_id)
        if not info:
            return False
        w = info.worker
        # cooperative cancel
        if hasattr(w, "cancel"):
            try:
                w.cancel()
            except Exception:
                pass
        # emit cancel immediately; actual thread may finish later.
        self.task_canceled.emit(task_id, info.name)
        if self.bus is not None:
            self.bus.publish("task.canceled", task_id=task_id, name=info.name, meta=info.meta)
        return True

    # ----------------------
    # Internal
    # ----------------------
    def _on_finished(self, task_id: str) -> None:
        info = self._tasks.pop(task_id, None)
        if not info:
            return
        self.task_finished.emit(task_id, info.name)
        if self.bus is not None:
            self.bus.publish("task.finished", task_id=task_id, name=info.name, meta=info.meta)

    def _on_failed(self, task_id: str, err: str) -> None:
        info = self._tasks.pop(task_id, None)
        if not info:
            return
        self.task_failed.emit(task_id, info.name, err)
        if self.bus is not None:
            self.bus.publish("task.failed", task_id=task_id, name=info.name, err=err, meta=info.meta)
