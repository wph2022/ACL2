from typing import Dict
import re

class BaseLogParser:
    log_type="base"; keyword=""
    _re_full=re.compile(r"\b(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?)\b")
    _re_md=re.compile(r"\b(\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?)\b")
    _re_hms=re.compile(r"\b(\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?)\b")
    _re_k=re.compile(r"\[\s*(\d+(?:\.\d+)?)\s*\]")
    def match(self,line:str)->bool: return (not self.keyword) or (self.keyword.lower() in line.lower())
    def ts(self,line:str)->str:
        s=line.strip()
        for rx in (self._re_full,self._re_md,self._re_hms):
            m=rx.search(s)
            if m: return m.group(1)
        cs=self._re_k.findall(s); return cs[0] if cs else ""
    def parse_line(self,line:str)->Dict[str,str]: raise NotImplementedError
