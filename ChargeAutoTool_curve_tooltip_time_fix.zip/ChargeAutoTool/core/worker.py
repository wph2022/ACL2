from PySide6.QtCore import QThread, Signal

class BaseWorker(QThread):
    log_signal = Signal(str)
