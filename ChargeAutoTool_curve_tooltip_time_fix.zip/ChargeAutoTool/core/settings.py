from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from PySide6.QtCore import QSettings


@dataclass(frozen=True)
class SettingKeys:
    last_log_path: str = "paths/last_log_path"
    last_export_dir: str = "paths/last_export_dir"
    last_store_dir: str = "paths/last_store_dir"
    window_geometry: str = "ui/window_geometry"
    window_state: str = "ui/window_state"


class AppSettings:
    """Thin wrapper around QSettings.

    - Centralizes keys
    - Provides safe getters/setters
    """

    def __init__(self, org: str = "ACL", app: str = "ChargeAutoTool"):
        self._qs = QSettings(org, app)
        self.keys = SettingKeys()

    def get_str(self, key: str, default: str = "") -> str:
        v = self._qs.value(key, defaultValue=default)
        return "" if v is None else str(v)

    def set_str(self, key: str, value: str) -> None:
        self._qs.setValue(key, value)

    def get_bytes(self, key: str) -> Optional[bytes]:
        v = self._qs.value(key)
        if v is None:
            return None
        # Qt may return QByteArray; bytes() handles it.
        try:
            return bytes(v)
        except Exception:
            return None

    def set_bytes(self, key: str, value: bytes) -> None:
        self._qs.setValue(key, value)
