@echo off
setlocal

REM Build ChargeAutoTool exe from repository root.
cd /d %~dp0\..

if not exist assets\icons\acl.ico (
  echo [WARN] assets\icons\acl.ico not found, EXE icon may not be set.
)

python -m pip install --upgrade pyinstaller
python -m PyInstaller -y --clean --windowed --name ChargeAutoTool ^
  --icon assets/icons/acl.ico ^
  --collect-binaries python ^
  --collect-binaries PySide6 ^
  --add-data "assets;assets" ^
  ChargeAutoTool/run.py

echo.
echo Build done. EXE location: dist\ChargeAutoTool\ChargeAutoTool.exe
endlocal
